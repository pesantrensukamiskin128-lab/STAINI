<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>KRS - {{ $krs->student?->nim }}</title>
    <style>
        @page { margin: 5mm 12mm 8mm 12mm; }
        body { font-family: 'Times New Roman', serif; font-size: 9pt; margin: 0; padding: 0; line-height: 1; position: relative; }
        table { width: 100%; border-collapse: collapse; }
        .bordered td, .bordered th { border: 1px solid #000; padding: 2px 4px; vertical-align: top; line-height: 1; }
        .bordered th { font-weight: bold; text-align: center; }
        .header-table { border: 1px solid #000; }
        .header-table td { padding: 6px; vertical-align: middle; border: none; }
        .header-logo { width: 80px; text-align: center; border-right: 1px solid #000 !important; }
        .header-logo img { max-width: 65px; max-height: 65px; }
        .header-text { font-size: 12pt; font-weight: bold; }
        .title-row { border: 1px solid #000; border-top: none; }
        .title-row td { text-align: center; padding: 4px; font-size: 11pt; font-weight: bold; }
        .info-table td { padding: 1px 4px; font-size: 9pt; border: none; }
        .info-label { width: 140px; font-weight: bold; }
        .signatures { margin-top: 12px; page-break-inside: avoid; }
        .sign-table td { padding: 3px 6px; text-align: center; vertical-align: top; border: none; width: 33%; }
        .sign-qr { width: 38px; height: 38px; vertical-align: middle; }
        .sign-qr-wrap { height: 44px; line-height: 44px; text-align: center; }
        .sign-qr-placeholder { height: 44px; }
        .sign-name { font-weight: bold; text-decoration: underline; font-size: 9pt; }
        .sign-role { font-size: 8pt; }
        .verification-footer { position: fixed; left: 0; right: 0; bottom: 2mm; border-top: 1px solid #ccc; padding: 3px 0 0; }
        p { margin: 2px 0; }
    </style>
</head>
<body>

{{-- HEADER --}}
@php
    $letterheadPath = $institution?->letterhead_path ? storage_path('app/public/' . $institution->letterhead_path) : null;
@endphp

@if($letterheadPath && file_exists($letterheadPath))
    <div style="text-align:center; margin-bottom:3px;">
        <img src="{{ $letterheadPath }}" alt="Kop Surat" style="width:100%;">
    </div>
@else
    <table class="header-table">
        <tr>
            <td class="header-logo">
                @if($logoPath && file_exists($logoPath))
                    <img src="{{ $logoPath }}" alt="Logo">
                @endif
            </td>
            <td class="header-text">
                {{ strtoupper($institution?->name ?? 'PERGURUAN TINGGI') }}<br>
                @if($krs->student?->studyProgram?->faculty)
                    {{ strtoupper($krs->student->studyProgram->faculty->name) }}<br>
                @endif
                PROGRAM STUDI {{ strtoupper($krs->student?->studyProgram?->name ?? '') }}
            </td>
        </tr>
    </table>
@endif
<div style="text-align:center; padding:4px 0; font-size:11pt; font-weight:bold;">
    KARTU RENCANA STUDI (KRS)
</div>

@php
    $formatIndonesianDate = static function ($date): string {
        if (!$date) {
            return '......................';
        }

        $months = [
            1 => 'Januari', 2 => 'Februari', 3 => 'Maret', 4 => 'April',
            5 => 'Mei', 6 => 'Juni', 7 => 'Juli', 8 => 'Agustus',
            9 => 'September', 10 => 'Oktober', 11 => 'November', 12 => 'Desember',
        ];

        return $date->format('j').' '.$months[(int) $date->format('n')].' '.$date->format('Y');
    };
@endphp

{{-- INFO MAHASISWA --}}
<table class="info-table" style="margin-top: 6px;">
    <tr><td class="info-label">NIM</td><td>: {{ $krs->student?->nim }}</td></tr>
    <tr><td class="info-label">Nama Mahasiswa</td><td>: {{ $krs->student?->name }}</td></tr>
    <tr><td class="info-label">Program Studi</td><td>: {{ $krs->student?->studyProgram?->name }}</td></tr>
    <tr><td class="info-label">Semester</td><td>: {{ $krs->semester?->name }}</td></tr>
    <tr><td class="info-label">Dosen Pembimbing Akademik</td><td>: {{ $krs->advisor?->display_name ?? $krs->advisor?->full_name ?? '-' }}</td></tr>
    <tr><td class="info-label">Total SKS</td><td>: {{ $krs->total_credits }} SKS</td></tr>
</table>

{{-- TABEL MK --}}
<table class="bordered" style="margin-top: 6px;">
    <thead>
        <tr>
            <th style="width:30px;">No</th>
            <th style="width:80px;">Kode MK</th>
            <th>Mata Kuliah</th>
            <th style="width:40px;">SKS</th>
            <th style="width:60px;">Kelas</th>
            <th>Dosen Pengampu</th>
        </tr>
    </thead>
    <tbody>
        @foreach($krs->details ?? [] as $i => $d)
        <tr>
            <td style="text-align:center;">{{ $i + 1 }}</td>
            <td style="text-align:center; font-size:10pt;">{{ $d->course?->code }}</td>
            <td>{{ $d->course?->name }}</td>
            <td style="text-align:center;">{{ $d->course?->credits }}</td>
            <td style="text-align:center;">{{ $d->class_?->name ?? '-' }}</td>
            <td>{{ $d->class_?->lecturer?->display_name ?? $d->class_?->lecturer?->full_name ?? '-' }}</td>
        </tr>
        @endforeach
    </tbody>
    <tfoot>
        <tr>
            <td colspan="3" style="text-align:right; font-weight:bold;">Total SKS:</td>
            <td style="text-align:center; font-weight:bold;">{{ $krs->total_credits }}</td>
            <td colspan="2"></td>
        </tr>
    </tfoot>
</table>

{{-- TANDA TANGAN --}}
<div class="signatures">
    <table class="sign-table" style="width:100%;">
        <tr>
            <td>
                <p style="font-size:9pt;">Ditandatangani Tanggal:<br><strong>{{ $formatIndonesianDate($krs->signed_by_kaprodi_at) }}</strong></p>
                <p><strong>Ketua Program Studi</strong></p>
                <div class="sign-qr-wrap">
                    @if($krs->signed_by_kaprodi_at)
                        <img src="{{ $qrKaprodi }}" alt="QR" class="sign-qr">
                    @endif
                </div>
                <span class="sign-name">{{ $kaprodi?->display_name ?? $kaprodi?->full_name ?? '-' }}</span><br>
                <span class="sign-role">NIDN: {{ $kaprodi?->nidn ?? '-' }}</span>
            </td>
            <td>
                <p style="font-size:9pt;">Disetujui Tanggal:<br><strong>{{ $formatIndonesianDate($krs->approved_at) }}</strong></p>
                <p><strong>Dosen Pembimbing Akademik</strong></p>
                <div class="sign-qr-wrap">
                    @if($krs->status === 'APPROVED')
                        <img src="{{ $qrAdvisor }}" alt="QR" class="sign-qr">
                    @endif
                </div>
                <span class="sign-name">{{ $krs->advisor?->display_name ?? $krs->advisor?->full_name ?? '-' }}</span><br>
                <span class="sign-role">NIDN: {{ $krs->advisor?->nidn ?? '-' }}</span>
            </td>
            <td>
                <p style="font-size:9pt;">Diajukan Tanggal:<br><strong>{{ $formatIndonesianDate($krs->submitted_at) }}</strong></p>
                <p><strong>Mahasiswa</strong></p>
                <div class="sign-qr-wrap">
                    @if($krs->status === 'APPROVED')
                        <img src="{{ $qrStudent }}" alt="QR" class="sign-qr">
                    @endif
                </div>
                <span class="sign-name">{{ $krs->student?->name ?? '-' }}</span><br>
                <span class="sign-role">NIM: {{ $krs->student?->nim ?? '-' }}</span>
            </td>
        </tr>
    </table>
</div>

<div style="margin-top: 5px; text-align: center; font-size: 8pt; color: #555;">
    Status: {{ $krs->status }}
</div>

{{-- Footer Verifikasi Elektronik di bagian bawah kertas --}}
<div class="verification-footer">
    <table style="width:100%; border:none;">
        <tr>
            <td style="width:42px; border:none; padding:0; vertical-align:middle;">
                <a href="{{ $verifyUrl }}"><img src="{{ $qrFooter }}" width="40" height="40" alt="QR Verifikasi"></a>
            </td>
            <td style="border:none; padding:0 0 0 5px; vertical-align:middle; font-size:8pt; color:#555; line-height:1;">
                Dokumen ini telah ditandatangani dan distempel secara elektronik melalui aplikasi Al-Jawami Smart Campus, klik atau scan QR Code untuk verifikasi.
            </td>
        </tr>
    </table>
</div>

</body>
</html>
