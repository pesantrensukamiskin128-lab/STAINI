<?php

namespace App\Http\Controllers\Api;

use App\Helpers\QrCodeHelper;
use App\Http\Controllers\Controller;
use App\Models\AppNotification;
use App\Models\ClassModel;
use App\Models\Curriculum;
use App\Models\Institution;
use App\Models\Lecturer;
use App\Models\LecturerPosition;
use App\Models\Rpkps;
use App\Models\RpkpsCpmk;
use App\Models\RpkpsWeeklyPlan;
use App\Models\Semester;
use App\Exports\RpkpsWorkbookExport;
use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;
use Illuminate\Validation\ValidationException;
use Maatwebsite\Excel\Facades\Excel;

class RpkpsController extends Controller
{
    /** List RPKPS (dengan filter) */
    public function index(Request $request): JsonResponse
    {
        $user = $request->user();
        $isSuperAdmin = $user->hasRole('SUPER_ADMIN') || $user->hasRole('ADMIN_AKADEMIK');
        $isMahasiswa = $user->hasRole('MAHASISWA');

        $data = Rpkps::with(['course', 'lecturer', 'curriculum', 'academicYear'])
            ->when($request->search, fn ($q) => $q->whereHas('course', fn ($c) => $c->where('name', 'like', "%{$request->search}%")
                ->orWhere('code', 'like', "%{$request->search}%")))
            ->when($request->course_id, fn ($q) => $q->where('course_id', $request->course_id))
            ->when($request->lecturer_id, fn ($q) => $q->where('lecturer_id', $request->lecturer_id))
            ->when($request->status, fn ($q) => $q->where('status', $request->status))
            ->when($request->academic_year_id, fn ($q) => $q->where('academic_year_id', $request->academic_year_id))
            // Mahasiswa: hanya lihat RPS yang sudah disetujui/dikunci
            ->when($isMahasiswa, fn ($q) => $q->whereIn('status', ['DISETUJUI', 'DIKUNCI']))
            // Dosen/admin: filter berdasarkan role
            ->when(! $isSuperAdmin && ! $isMahasiswa, function ($q) use ($user) {
                $lecturer = Lecturer::where('user_id', $user->id)->first();
                if (! $lecturer) {
                    $q->whereRaw('1 = 0');

                    return;
                }

                // Cek apakah Kaprodi/Sekprodi → bisa lihat semua RPS di prodinya
                $isKaprodi = LecturerPosition::where('lecturer_id', $lecturer->id)
                    ->where('is_active', true)
                    ->whereIn('position_code', ['KAPRODI', 'SEKPRODI'])
                    ->exists();

                if ($isKaprodi) {
                    $prodiId = $lecturer->study_program_id;
                    $q->whereHas('course', fn ($cq) => $cq->where('study_program_id', $prodiId));
                } else {
                    $q->where('lecturer_id', $lecturer->id);
                }
            })
            ->orderByDesc('created_at')
            ->paginate($request->per_page ?? 15);

        return response()->json($data);
    }

    /** Mata kuliah yang bisa dibuat RPS oleh dosen (yang ditugaskan via kelas) */
    public function myAssignedCourses(Request $request): JsonResponse
    {
        $user = $request->user();
        $lecturer = Lecturer::where('user_id', $user->id)->first();

        if (! $lecturer) {
            return response()->json([]);
        }

        $classes = ClassModel::query()
            ->where('is_active', true)
            ->where(function ($query) use ($lecturer) {
                $query->where('lecturer_id', $lecturer->id)
                    ->orWhereHas('lecturers', fn ($lecturerQuery) => $lecturerQuery->where('lecturers.id', $lecturer->id))
                    ->orWhereHas('schedules', fn ($scheduleQuery) => $scheduleQuery->where('lecturer_id', $lecturer->id));
            })
            ->with(['course:id,study_program_id,code,name,credits', 'offeredCourses:id,study_program_id,code,name,credits'])
            ->get();

        $courses = $classes
            ->flatMap(fn ($class) => $class->offeredCourses->isNotEmpty() ? $class->offeredCourses : collect([$class->course]))
            ->filter()
            ->unique('id')
            ->values();

        return response()->json([
            'lecturer_id' => $lecturer->id,
            'courses' => $courses,
        ]);
    }

    /** Buat RPKPS baru */
    public function store(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'course_id' => 'required|exists:courses,id',
            'curriculum_id' => 'required|exists:curriculums,id',
            'academic_year_id' => 'required|exists:academic_years,id',
            'semester_id' => 'nullable|exists:semesters,id',
            'lecturer_id' => 'required|exists:lecturers,id',
            'coordinator_id' => 'nullable|exists:lecturers,id',
            'course_description' => 'nullable|string',
            'course_urgency' => 'nullable|string',
            'course_scope' => 'nullable|string',
            'course_position' => 'nullable|string',
            'prerequisites' => 'nullable|string',
        ]);

        if (! Curriculum::whereKey($validated['curriculum_id'])->where('status', 'Aktif')->exists()) {
            return response()->json(['message' => 'RPS hanya dapat dibuat menggunakan kurikulum yang aktif.'], 422);
        }

        // Validasi: Dosen hanya bisa buat RPS untuk MK yang diampu
        $user = $request->user();
        $isSuperAdmin = $user->hasRole('SUPER_ADMIN') || $user->hasRole('ADMIN_AKADEMIK');

        if (! $isSuperAdmin) {
            $lecturer = Lecturer::where('user_id', $user->id)->first();
            if (! $lecturer || $lecturer->id != $validated['lecturer_id']) {
                return response()->json(['message' => 'Anda hanya bisa membuat RPKPS untuk diri sendiri.'], 403);
            }

            // Pengampu utama, pengampu tim, dan dosen pada jadwal kelas diakui.
            $isAssigned = ClassModel::query()
                ->where('is_active', true)
                ->whereHas('offeredCourses', fn ($courseQuery) => $courseQuery->where('courses.id', $validated['course_id']))
                ->where(function ($query) use ($lecturer) {
                    $query->where('lecturer_id', $lecturer->id)
                        ->orWhereHas('lecturers', fn ($lecturerQuery) => $lecturerQuery->where('lecturers.id', $lecturer->id))
                        ->orWhereHas('schedules', fn ($scheduleQuery) => $scheduleQuery->where('lecturer_id', $lecturer->id));
                })
                ->exists();

            if (! $isAssigned) {
                return response()->json([
                    'message' => 'Anda belum ditugaskan mengampu mata kuliah ini. Hubungi Kaprodi untuk penugasan.',
                ], 403);
            }
        }

        $curriculumContainsCourse = Curriculum::whereKey($validated['curriculum_id'])
            ->whereHas('courses', fn ($query) => $query->where('courses.id', $validated['course_id']))
            ->exists();
        if (! $curriculumContainsCourse) {
            return response()->json(['message' => 'Mata kuliah tidak tercantum dalam kurikulum yang dipilih.'], 422);
        }

        $validated['code'] = Rpkps::generateCode($validated['course_id']);

        // Auto-fill semester aktif jika tidak diisi
        if (empty($validated['semester_id'])) {
            $activeSemester = Semester::where('is_active', true)->first();
            if ($activeSemester) {
                $validated['semester_id'] = $activeSemester->id;
            }
        }

        $rpkps = Rpkps::create($validated);

        // Otomatis sync CPL dari pemetaan kurikulum (cpl_course_mappings)
        $cplIds = DB::table('cpl_course_mappings')
            ->where('course_id', $validated['course_id'])
            ->whereIn('learning_outcome_id', function ($q) use ($validated) {
                $q->select('id')->from('learning_outcomes')
                    ->where('curriculum_id', $validated['curriculum_id']);
            })
            ->pluck('learning_outcome_id')
            ->toArray();

        if ($cplIds) {
            $rpkps->cpls()->sync($cplIds);
        }

        return response()->json(['message' => 'RPKPS berhasil dibuat.', 'data' => $rpkps->load(['course', 'lecturer', 'cpls'])], 201);
    }

    /** Detail RPKPS lengkap */
    public function show(Rpkps $rpkp): JsonResponse
    {
        return response()->json($rpkp->load([
            'course.studyProgram.faculty',
            'curriculum', 'academicYear', 'semester',
            'lecturer', 'coordinator', 'approvedByUser',
            'cpls', 'cpmks.subCpmks', 'cpmks.cpls',
            'learningMaterials', 'weeklyPlans',
            'assessments.rubrics', 'gradeScales', 'assessmentInstruments', 'rubrics',
            'references', 'approvals.user',
        ]));
    }

    /** Update data deskripsi RPKPS */
    public function update(Request $request, Rpkps $rpkp): JsonResponse
    {
        $this->authorizeDocumentEdit($rpkp);
        if (in_array($rpkp->status, ['DIKUNCI', 'DIARSIPKAN'])) {
            return response()->json(['message' => 'RPKPS sudah dikunci, tidak bisa diubah.'], 422);
        }

        $validated = $request->validate([
            'course_description' => 'nullable|string',
            'course_urgency' => 'nullable|string',
            'course_scope' => 'nullable|string',
            'course_position' => 'nullable|string',
            'prerequisites' => 'nullable|string',
            'coordinator_id' => 'nullable|exists:lecturers,id',
        ]);

        $rpkp->update($validated);

        return response()->json(['message' => 'RPKPS berhasil diupdate.', 'data' => $rpkp->fresh()]);
    }

    /** Sync CPL yang dipilih */
    public function syncCpls(Request $request, Rpkps $rpkp): JsonResponse
    {
        $this->authorizeDocumentEdit($rpkp);
        $request->validate(['cpl_ids' => 'required|array', 'cpl_ids.*' => 'exists:learning_outcomes,id']);
        $rpkp->cpls()->sync($request->cpl_ids);

        return response()->json(['message' => 'CPL berhasil disinkronkan.']);
    }

    /** CRUD CPMK */
    public function storeCpmk(Request $request, Rpkps $rpkp): JsonResponse
    {
        $this->authorizeDocumentEdit($rpkp);
        $validated = $request->validate([
            'code' => 'required|string|max:20',
            'description' => 'required|string',
            'cpl_ids' => 'nullable|array',
            'cpl_ids.*' => 'exists:learning_outcomes,id',
            'sub_cpmks' => 'nullable|array',
            'sub_cpmks.*.code' => 'required|string|max:20',
            'sub_cpmks.*.description' => 'required|string',
        ]);

        $cpmk = $rpkp->cpmks()->create([
            'code' => $validated['code'],
            'description' => $validated['description'],
            'order' => $rpkp->cpmks()->count() + 1,
        ]);

        if (! empty($validated['cpl_ids'])) {
            $cpmk->cpls()->sync($validated['cpl_ids']);
        }

        if (! empty($validated['sub_cpmks'])) {
            foreach ($validated['sub_cpmks'] as $i => $sub) {
                $cpmk->subCpmks()->create(['code' => $sub['code'], 'description' => $sub['description'], 'order' => $i + 1]);
            }
        }

        return response()->json(['message' => 'CPMK berhasil ditambahkan.', 'data' => $cpmk->load(['subCpmks', 'cpls'])], 201);
    }

    public function updateCpmk(Request $request, Rpkps $rpkp, RpkpsCpmk $cpmk): JsonResponse
    {
        $this->authorizeDocumentEdit($rpkp);
        $validated = $request->validate([
            'code' => 'sometimes|string|max:20',
            'description' => 'sometimes|string',
            'cpl_ids' => 'nullable|array',
        ]);

        $cpmk->update(collect($validated)->except('cpl_ids')->toArray());
        if (isset($validated['cpl_ids'])) {
            $cpmk->cpls()->sync($validated['cpl_ids']);
        }

        return response()->json(['message' => 'CPMK berhasil diupdate.', 'data' => $cpmk->fresh(['subCpmks', 'cpls'])]);
    }

    public function destroyCpmk(Rpkps $rpkp, RpkpsCpmk $cpmk): JsonResponse
    {
        $this->authorizeDocumentEdit($rpkp);
        $cpmk->delete();

        return response()->json(['message' => 'CPMK berhasil dihapus.']);
    }

    /** Batch save weekly plans (16 minggu sekaligus) */
    public function saveWeeklyPlans(Request $request, Rpkps $rpkp): JsonResponse
    {
        $this->authorizeDocumentEdit($rpkp);
        $validated = $request->validate([
            'plans' => 'required|array',
            'plans.*.week_number' => 'required|integer|min:1|max:16',
            'plans.*.sub_cpmk' => 'nullable|string',
            'plans.*.indicators' => 'nullable|string',
            'plans.*.learning_material' => 'nullable|string',
            'plans.*.methods' => 'nullable|array',
            'plans.*.offline_learning' => 'nullable|string',
            'plans.*.online_learning' => 'nullable|string',
            'plans.*.lecturer_activity' => 'nullable|string',
            'plans.*.student_activity' => 'nullable|string',
            'plans.*.assessment_form' => 'nullable|string',
            'plans.*.assessment_criteria' => 'nullable|string',
            'plans.*.media' => 'nullable|string',
            'plans.*.duration' => 'nullable|string',
            'plans.*.weight' => 'nullable|integer|min:0',
        ]);

        DB::transaction(function () use ($rpkp, $validated) {
            foreach ($validated['plans'] as $plan) {
                RpkpsWeeklyPlan::updateOrCreate(
                    ['rpkps_id' => $rpkp->id, 'week_number' => $plan['week_number']],
                    $plan
                );
            }
        });

        return response()->json(['message' => 'Rencana mingguan berhasil disimpan.']);
    }

    /** Save assessments (komponen penilaian) */
    public function saveAssessments(Request $request, Rpkps $rpkp): JsonResponse
    {
        $this->authorizeDocumentEdit($rpkp);
        $validated = $request->validate([
            'assessments' => 'required|array',
            'assessments.*.id' => [
                'nullable',
                Rule::exists('rpkps_assessments', 'id')
                    ->where(fn ($query) => $query->where('rpkps_id', $rpkp->id)),
            ],
            'assessments.*.name' => 'required|string',
            'assessments.*.weight' => 'required|integer|min:0|max:100',
            'assessments.*.description' => 'nullable|string',
            'final_grade_formula' => 'nullable|string',
            'grade_scales' => 'nullable|array',
            'grade_scales.*.min_score' => 'required|numeric|min:0|max:100',
            'grade_scales.*.max_score' => 'required|numeric|min:0|max:100',
            'grade_scales.*.letter' => 'required|string|max:5',
            'grade_scales.*.grade_point' => 'required|numeric|min:0|max:4',
        ]);

        // Validasi total bobot = 100
        $total = collect($validated['assessments'])->sum('weight');
        if ($total !== 100) {
            return response()->json(['message' => "Total bobot harus 100%. Saat ini: {$total}%."], 422);
        }

        DB::transaction(function () use ($rpkp, $validated) {
            $retainedIds = [];
            foreach ($validated['assessments'] as $i => $a) {
                $assessmentId = $a['id'] ?? null;
                unset($a['id']);
                $assessment = $assessmentId
                    ? $rpkp->assessments()->findOrFail($assessmentId)
                    : $rpkp->assessments()->make();
                $assessment->fill(array_merge($a, ['order' => $i + 1]));
                $assessment->save();
                $retainedIds[] = $assessment->id;
            }
            $rpkp->assessments()->whereNotIn('id', $retainedIds)->delete();
            $rpkp->update(['final_grade_formula' => $validated['final_grade_formula'] ?? null]);
            $rpkp->gradeScales()->delete();
            foreach ($validated['grade_scales'] ?? [] as $i => $scale) {
                if ((float) $scale['max_score'] < (float) $scale['min_score']) {
                    throw ValidationException::withMessages([
                        "grade_scales.{$i}.max_score" => 'Nilai maksimum tidak boleh lebih kecil daripada nilai minimum.',
                    ]);
                }
                $rpkp->gradeScales()->create(array_merge($scale, ['order' => $i + 1]));
            }
        });

        return response()->json(['message' => 'Komponen asesmen berhasil disimpan.']);
    }

    /** Simpan kisi-kisi instrumen dan rubrik penilaian. */
    public function saveEvaluationTools(Request $request, Rpkps $rpkp): JsonResponse
    {
        $this->authorizeDocumentEdit($rpkp);
        $assessmentRule = Rule::exists('rpkps_assessments', 'id')
            ->where(fn ($query) => $query->where('rpkps_id', $rpkp->id));

        $validated = $request->validate([
            'instruments' => 'nullable|array',
            'instruments.*.rpkps_assessment_id' => ['nullable', $assessmentRule],
            'instruments.*.sub_cpmk' => 'nullable|string',
            'instruments.*.instrument_name' => 'required|string|max:255',
            'instruments.*.instrument_type' => 'nullable|string|max:50',
            'instruments.*.technique' => 'nullable|string|max:100',
            'instruments.*.cognitive_level' => 'nullable|string|max:30',
            'instruments.*.affective_level' => 'nullable|string|max:30',
            'instruments.*.psychomotor_level' => 'nullable|string|max:30',
            'instruments.*.item_numbers' => 'nullable|string|max:100',
            'instruments.*.weight' => 'nullable|integer|min:0|max:100',
            'instruments.*.timing' => 'nullable|string|max:100',
            'instruments.*.description' => 'nullable|string',
            'rubrics' => 'nullable|array',
            'rubrics.*.rpkps_assessment_id' => ['nullable', $assessmentRule],
            'rubrics.*.title' => 'nullable|string|max:255',
            'rubrics.*.criteria' => 'required|string|max:255',
            'rubrics.*.weight' => 'nullable|integer|min:0|max:100',
            'rubrics.*.excellent' => 'nullable|string',
            'rubrics.*.good' => 'nullable|string',
            'rubrics.*.fair' => 'nullable|string',
            'rubrics.*.poor' => 'nullable|string',
            'rubrics.*.very_poor' => 'nullable|string',
        ]);

        DB::transaction(function () use ($rpkp, $validated): void {
            $rpkp->assessmentInstruments()->delete();
            foreach ($validated['instruments'] ?? [] as $i => $instrument) {
                $rpkp->assessmentInstruments()->create(array_merge($instrument, ['order' => $i + 1]));
            }

            $rpkp->rubrics()->delete();
            foreach ($validated['rubrics'] ?? [] as $i => $rubric) {
                $rpkp->rubrics()->create(array_merge($rubric, ['order' => $i + 1]));
            }
        });

        return response()->json(['message' => 'Kisi-kisi instrumen dan rubrik berhasil disimpan.']);
    }

    /** Save references */
    public function saveReferences(Request $request, Rpkps $rpkp): JsonResponse
    {
        $this->authorizeDocumentEdit($rpkp);
        $validated = $request->validate([
            'references' => 'required|array',
            'references.*.type' => 'required|in:Utama,Pendukung',
            'references.*.category' => 'required|string',
            'references.*.title' => 'required|string',
            'references.*.author' => 'nullable|string',
            'references.*.year' => 'nullable|string',
            'references.*.publisher' => 'nullable|string',
            'references.*.isbn_doi' => 'nullable|string',
            'references.*.url' => 'nullable|string',
        ]);

        DB::transaction(function () use ($rpkp, $validated) {
            $rpkp->references()->delete();
            foreach ($validated['references'] as $i => $r) {
                $rpkp->references()->create(array_merge($r, ['order' => $i + 1]));
            }
        });

        return response()->json(['message' => 'Referensi berhasil disimpan.']);
    }

    public function exportExcel(Rpkps $rpkp)
    {
        $this->authorizeDocumentEdit($rpkp);
        $rpkp->load(['cpmks.subCpmks','learningMaterials','weeklyPlans','assessments','assessmentInstruments.assessment','rubrics.assessment','gradeScales','references']);
        return Excel::download(new RpkpsWorkbookExport($rpkp), 'RPKPS-'.$rpkp->code.'.xlsx');
    }

    public function templateExcel()
    {
        return Excel::download(new RpkpsWorkbookExport(null, true), 'template-import-RPKPS.xlsx');
    }

    public function importExcel(Request $request, Rpkps $rpkp): JsonResponse
    {
        $this->authorizeDocumentEdit($rpkp);
        $request->validate(['file' => 'required|file|mimes:xlsx,xls|max:10240']);
        $sheets = Excel::toArray([], $request->file('file'));
        $byName = [];
        foreach ($sheets as $sheet) {
            if (!$sheet) continue;
            $header = array_map(fn ($v) => trim((string) $v), array_shift($sheet));
            $byName[$this->excelSheetName($header, $sheet)] = collect($sheet)
                ->filter(fn ($row) => collect($row)->filter(fn ($v) => $v !== null && $v !== '')->isNotEmpty())
                ->map(fn ($row) => collect($header)->combine(array_pad($row, count($header), null))->all())
                ->values();
        }

        $cpmkRows = $byName['CPMK'] ?? collect();
        $assessmentRows = $byName['ASESMEN'] ?? collect();
        $totalWeight = $assessmentRows->sum(fn ($r) => (int) ($r['weight'] ?? 0));
        if ($totalWeight !== 100) {
            throw ValidationException::withMessages(['file' => "Total bobot ASESMEN harus 100%. Saat ini {$totalWeight}%."]);
        }

        DB::transaction(function () use ($rpkp, $byName, $cpmkRows, $assessmentRows): void {
            foreach (['cpmks','learningMaterials','weeklyPlans','assessments','gradeScales','assessmentInstruments','rubrics','references'] as $relation) {
                $rpkp->{$relation}()->delete();
            }
            $cpmks = [];
            foreach ($cpmkRows as $i => $row) {
                $cpmks[(string) $row['code']] = $rpkp->cpmks()->create([
                    'code' => $row['code'], 'description' => $row['description'], 'order' => $row['order'] ?? $i + 1,
                ]);
            }
            foreach (($byName['SUB_CPMK'] ?? collect()) as $i => $row) {
                if (isset($cpmks[(string) $row['cpmk_code']])) {
                    $cpmks[(string) $row['cpmk_code']]->subCpmks()->create([
                        'code' => $row['code'], 'description' => $row['description'], 'order' => $row['order'] ?? $i + 1,
                    ]);
                }
            }
            foreach (($byName['BAHAN_KAJIAN'] ?? collect()) as $i => $row) {
                $rpkp->learningMaterials()->create(['topic'=>$row['topic'],'subtopics'=>$row['subtopics'] ?? null,'order'=>$row['order'] ?? $i + 1]);
            }
            foreach (($byName['RENCANA_MINGGUAN'] ?? collect()) as $row) {
                $rpkp->weeklyPlans()->create(array_merge($row, ['methods' => !empty($row['methods']) ? explode('|', $row['methods']) : []]));
            }
            $assessments = [];
            foreach ($assessmentRows as $i => $row) {
                $assessments[(string) $row['name']] = $rpkp->assessments()->create([
                    'name'=>$row['name'],'weight'=>(int)$row['weight'],'description'=>$row['description'] ?? null,'order'=>$row['order'] ?? $i + 1,
                ]);
                $rpkp->final_grade_formula = $row['final_grade_formula'] ?? $rpkp->final_grade_formula;
            }
            $rpkp->save();
            foreach (($byName['SKALA_NILAI'] ?? collect()) as $i => $row) {
                $rpkp->gradeScales()->create(array_merge($row, ['order'=>$row['order'] ?? $i + 1]));
            }
            foreach (($byName['INSTRUMEN'] ?? collect()) as $i => $row) {
                $data = collect($row)->except('assessment_name')->all();
                $data['rpkps_assessment_id'] = $assessments[(string) ($row['assessment_name'] ?? '')]->id ?? null;
                $data['order'] = $row['order'] ?? $i + 1;
                $rpkp->assessmentInstruments()->create($data);
            }
            foreach (($byName['RUBRIK'] ?? collect()) as $i => $row) {
                $data = collect($row)->except('assessment_name')->all();
                $data['rpkps_assessment_id'] = $assessments[(string) ($row['assessment_name'] ?? '')]->id ?? null;
                $data['order'] = $row['order'] ?? $i + 1;
                $rpkp->rubrics()->create($data);
            }
            foreach (($byName['REFERENSI'] ?? collect()) as $i => $row) {
                $rpkp->references()->create(array_merge($row, ['order'=>$row['order'] ?? $i + 1]));
            }
        });
        return response()->json(['message' => 'RPKPS berhasil diimport. CPL tetap mengikuti kurikulum.']);
    }

    private function excelSheetName(array $header, $rows): string
    {
        return match (true) {
            in_array('cpmk_code', $header, true) => 'SUB_CPMK',
            in_array('week_number', $header, true) => 'RENCANA_MINGGUAN',
            in_array('assessment_name', $header, true) && in_array('instrument_name', $header, true) => 'INSTRUMEN',
            in_array('assessment_name', $header, true) => 'RUBRIK',
            in_array('min_score', $header, true) => 'SKALA_NILAI',
            in_array('isbn_doi', $header, true) => 'REFERENSI',
            in_array('instrument_name', $header, true) => 'INSTRUMEN',
            in_array('criteria', $header, true) => 'RUBRIK',
            in_array('topic', $header, true) => 'BAHAN_KAJIAN',
            in_array('code', $header, true) && in_array('description', $header, true) => 'CPMK',
            in_array('name', $header, true) && in_array('weight', $header, true) => 'ASESMEN',
            default => 'IDENTITAS',
        };
    }

    // === WORKFLOW ===

    /** Ajukan RPKPS (DRAFT → DIAJUKAN) */
    public function submit(Rpkps $rpkp): JsonResponse
    {
        $this->authorizeDocumentEdit($rpkp);
        if ($rpkp->status !== 'DRAFT' && $rpkp->status !== 'REVISI') {
            return response()->json(['message' => 'RPKPS tidak dalam status yang bisa diajukan.'], 422);
        }
        $rpkp->update(['status' => 'DIAJUKAN']);
        $rpkp->approvals()->create(['user_id' => auth()->id(), 'action' => 'DIAJUKAN']);

        // Kirim notifikasi ke Kaprodi
        $rpkp->loadMissing(['course', 'lecturer']);
        $prodiId = $rpkp->course?->study_program_id;
        if ($prodiId) {
            // Cari Kaprodi prodi ini
            $kaprodiPosition = LecturerPosition::where('position_code', 'KAPRODI')
                ->where('scope_type', 'study_program')
                ->where('scope_id', $prodiId)
                ->where('is_active', true)
                ->first();

            if ($kaprodiPosition) {
                $kaprodiLecturer = Lecturer::find($kaprodiPosition->lecturer_id);
                if ($kaprodiLecturer?->user_id) {
                    AppNotification::send(
                        $kaprodiLecturer->user_id,
                        'Pengajuan RPKPS Baru',
                        "Dosen {$rpkp->lecturer?->full_name} mengajukan RPKPS untuk MK {$rpkp->course?->name}. Mohon direview.",
                        'warning',
                        '/rps/'.$rpkp->id
                    );
                }
            }
        }

        return response()->json(['message' => 'RPKPS berhasil diajukan untuk validasi.']);
    }

    /** Kaprodi: Setujui */
    public function approve(Request $request, Rpkps $rpkp): JsonResponse
    {
        $rpkp->update([
            'status' => 'DISETUJUI',
            'approved_by' => auth()->id(),
            'approved_at' => now(),
        ]);
        $rpkp->approvals()->create(['user_id' => auth()->id(), 'action' => 'DISETUJUI', 'note' => $request->note]);

        // Notifikasi ke dosen pembuat RPS
        $rpkp->loadMissing(['course', 'lecturer']);
        if ($rpkp->lecturer?->user_id) {
            AppNotification::send(
                $rpkp->lecturer->user_id,
                'RPKPS Disetujui ✓',
                "RPKPS untuk MK {$rpkp->course?->name} telah disetujui oleh Kaprodi.",
                'success',
                '/rps/'.$rpkp->id
            );
        }

        return response()->json(['message' => 'RPKPS berhasil disetujui.']);
    }

    /** Kaprodi: Minta revisi */
    public function revise(Request $request, Rpkps $rpkp): JsonResponse
    {
        $request->validate(['note' => 'required|string']);
        $rpkp->update(['status' => 'REVISI', 'revision_note' => $request->note]);
        $rpkp->approvals()->create(['user_id' => auth()->id(), 'action' => 'REVISI', 'note' => $request->note]);

        // Notifikasi ke dosen pembuat RPS
        $rpkp->loadMissing(['course', 'lecturer']);
        if ($rpkp->lecturer?->user_id) {
            AppNotification::send(
                $rpkp->lecturer->user_id,
                'RPKPS Perlu Revisi',
                "RPKPS untuk MK {$rpkp->course?->name} dikembalikan untuk revisi. Catatan: \"{$request->note}\"",
                'warning',
                '/rps/'.$rpkp->id
            );
        }

        return response()->json(['message' => 'RPKPS dikembalikan untuk revisi.']);
    }

    /** Kunci RPKPS (setelah disetujui) */
    public function lock(Rpkps $rpkp): JsonResponse
    {
        if ($rpkp->status !== 'DISETUJUI') {
            return response()->json(['message' => 'Hanya RPKPS yang disetujui yang bisa dikunci.'], 422);
        }
        $rpkp->update(['status' => 'DIKUNCI']);
        $rpkp->approvals()->create(['user_id' => auth()->id(), 'action' => 'DIKUNCI']);

        return response()->json(['message' => 'RPKPS berhasil dikunci.']);
    }

    /** Duplikasi ke semester baru */
    public function duplicate(Request $request, Rpkps $rpkp): JsonResponse
    {
        if (! in_array($rpkp->status, ['DISETUJUI', 'DIKUNCI', 'DIARSIPKAN'], true)) {
            return response()->json([
                'message' => 'Hanya RPKPS lama yang sudah disetujui, dikunci, atau diarsipkan yang dapat digunakan kembali.',
            ], 422);
        }

        $validated = $request->validate([
            'academic_year_id' => 'required|exists:academic_years,id',
            'semester_id' => 'nullable|exists:semesters,id',
            'curriculum_id' => 'nullable|exists:curriculums,id',
            'lecturer_id' => 'nullable|exists:lecturers,id',
        ]);

        if (! empty($validated['curriculum_id'])) {
            $validCurriculum = Curriculum::whereKey($validated['curriculum_id'])
                ->where('status', 'Aktif')
                ->whereHas('courses', fn ($query) => $query->where('courses.id', $rpkp->course_id))
                ->exists();
            if (! $validCurriculum) {
                return response()->json(['message' => 'Mata kuliah tidak tercantum dalam kurikulum tujuan.'], 422);
            }
        }

        $user = $request->user();
        $isAdmin = $user->hasAnyRole(['SUPER_ADMIN', 'ADMIN_AKADEMIK']);
        $lecturer = $user->lecturer;
        if (! $isAdmin) {
            abort_unless($lecturer && $this->lecturerIsAssignedToCourse($lecturer->id, $rpkp->course_id), 403,
                'Anda belum ditugaskan mengampu mata kuliah ini.');
        }

        $new = DB::transaction(function () use ($rpkp, $validated, $isAdmin, $lecturer) {
            $copy = $rpkp->duplicate($validated['academic_year_id'], $validated['semester_id'] ?? null);
            $copy->update([
                'curriculum_id' => $validated['curriculum_id'] ?? $rpkp->curriculum_id,
                'lecturer_id' => $isAdmin
                    ? ($validated['lecturer_id'] ?? $rpkp->lecturer_id)
                    : $lecturer->id,
                'status' => 'DRAFT',
                'revision_note' => null,
            ]);

            return $copy;
        });

        return response()->json(['message' => 'RPKPS lama berhasil digunakan sebagai draf baru dan siap direvisi.', 'data' => $new->load(['course', 'lecturer'])], 201);
    }

    public function reusable(Request $request): JsonResponse
    {
        $user = $request->user();
        $isAdmin = $user->hasAnyRole(['SUPER_ADMIN', 'ADMIN_AKADEMIK']);
        $courseIds = null;
        if (! $isAdmin) {
            $assigned = $this->myAssignedCourses($request)->getData(true);
            $courseIds = collect($assigned['courses'] ?? [])->pluck('id')->map(fn ($id) => (int) $id)->all();
        }

        return response()->json(Rpkps::with(['course:id,code,name,credits', 'lecturer:id,full_name', 'academicYear:id,name'])
            ->whereIn('status', ['DISETUJUI', 'DIKUNCI', 'DIARSIPKAN'])
            ->when($courseIds !== null, fn ($query) => $query->whereIn('course_id', $courseIds))
            ->when($request->course_id, fn ($query) => $query->where('course_id', $request->course_id))
            ->orderByDesc('academic_year_id')
            ->limit(100)
            ->get());
    }

    /** Statistik RPKPS (untuk dashboard) */
    public function statistics(Request $request): JsonResponse
    {
        $query = Rpkps::query()
            ->when($request->academic_year_id, fn ($q) => $q->where('academic_year_id', $request->academic_year_id));

        $stats = [
            'total' => (clone $query)->count(),
            'draft' => (clone $query)->where('status', 'DRAFT')->count(),
            'diajukan' => (clone $query)->where('status', 'DIAJUKAN')->count(),
            'dalam_pemeriksaan' => (clone $query)->where('status', 'DALAM_PEMERIKSAAN')->count(),
            'revisi' => (clone $query)->where('status', 'REVISI')->count(),
            'disetujui' => (clone $query)->where('status', 'DISETUJUI')->count(),
            'dikunci' => (clone $query)->where('status', 'DIKUNCI')->count(),
        ];

        return response()->json($stats);
    }

    /** Hapus RPKPS (hanya DRAFT) */
    public function destroy(Rpkps $rpkp): JsonResponse
    {
        $this->authorizeDocumentEdit($rpkp);
        if ($rpkp->status !== 'DRAFT') {
            return response()->json(['message' => 'Hanya RPKPS berstatus DRAFT yang bisa dihapus.'], 422);
        }
        $rpkp->delete();

        return response()->json(['message' => 'RPKPS berhasil dihapus.']);
    }

    /** Download PDF RPKPS dengan format standar dan QR code */
    public function downloadPdf(Rpkps $rpkp)
    {
        $rpkp->load([
            'course.studyProgram.faculty',
            'curriculum', 'academicYear', 'semester',
            'lecturer', 'coordinator',
            'cpls', 'cpmks.subCpmks', 'cpmks.cpls',
            'learningMaterials', 'weeklyPlans',
            'assessments', 'gradeScales', 'assessmentInstruments', 'rubrics', 'references',
        ]);

        $institution = Institution::first();
        $logoPath = $institution?->logo_path
            ? storage_path('app/public/'.$institution->logo_path)
            : null;

        // Cari Kaprodi
        $prodiId = $rpkp->course?->study_program_id;
        $kaprodi = null;
        if ($prodiId) {
            $kaprodiPosition = LecturerPosition::where('position_code', 'KAPRODI')
                ->where('scope_type', 'study_program')
                ->where('scope_id', $prodiId)
                ->where('is_active', true)
                ->first();
            if ($kaprodiPosition) {
                $kaprodi = Lecturer::find($kaprodiPosition->lecturer_id);
            }
        }

        // Identitas penjaminan mutu ditampilkan pada lembar otorisasi.
        $lpmPosition = LecturerPosition::where('position_code', 'KETUA_LPM')
            ->where('is_active', true)
            ->where(function ($query): void {
                $query->where('scope_type', 'institution')
                    ->orWhereNull('scope_type');
            })
            ->latest('id')
            ->first()
            ?? LecturerPosition::where('position_code', 'KETUA_LPM')
                ->where('is_active', true)
                ->latest('id')
                ->first();
        $lpm = $lpmPosition ? Lecturer::find($lpmPosition->lecturer_id) : null;

        // QR Code via helper (biru + logo untuk footer)
        $verifyUrl = rtrim(config('app.frontend_url'), '/')."/verify/rpkps/{$rpkp->verification_code}";
        $qrDosenUrl = QrCodeHelper::generate($verifyUrl.'?signer=dosen', 120);
        $qrLpmUrl = QrCodeHelper::generate($verifyUrl.'?signer=lpm', 120);
        $qrKaprodiUrl = QrCodeHelper::generate($verifyUrl.'?signer=kaprodi', 120);
        $qrFooter = QrCodeHelper::generateWithLogo($verifyUrl, 160);

        $pdf = Pdf::loadView('pdf.rpkps', [
            'rpkps' => $rpkp,
            'institution' => $institution,
            'logoPath' => $logoPath,
            'kaprodi' => $kaprodi,
            'lpm' => $lpm,
            'qrDosenUrl' => $qrDosenUrl,
            'qrLpmUrl' => $qrLpmUrl,
            'qrKaprodiUrl' => $qrKaprodiUrl,
            'qrFooter' => $qrFooter,
            'verifyUrl' => $verifyUrl,
        ])->setPaper('a4', 'landscape')
            ->setOption('isRemoteEnabled', true);

        $filename = "RPKPS-{$rpkp->course?->code}-{$rpkp->code}.pdf";

        return $pdf->download($filename);
    }

    private function lecturerIsAssignedToCourse(int $lecturerId, int $courseId): bool
    {
        return ClassModel::query()
            ->where('is_active', true)
            ->whereHas('offeredCourses', fn ($courseQuery) => $courseQuery->where('courses.id', $courseId))
            ->where(function ($query) use ($lecturerId) {
                $query->where('lecturer_id', $lecturerId)
                    ->orWhereHas('lecturers', fn ($lecturerQuery) => $lecturerQuery->where('lecturers.id', $lecturerId))
                    ->orWhereHas('schedules', fn ($scheduleQuery) => $scheduleQuery->where('lecturer_id', $lecturerId));
            })
            ->exists();
    }

    private function authorizeDocumentEdit(Rpkps $rpkps): void
    {
        $user = request()->user();
        if ($user?->hasAnyRole(['SUPER_ADMIN', 'ADMIN_AKADEMIK'])) {
            return;
        }

        $lecturerId = $user?->lecturer?->id;
        abort_unless(
            $lecturerId
            && (int) $rpkps->lecturer_id === (int) $lecturerId
            && $this->lecturerIsAssignedToCourse($lecturerId, $rpkps->course_id),
            403,
            'RPKPS hanya dapat direvisi oleh dosen penyusun yang masih ditugaskan mengampu mata kuliah tersebut.'
        );
    }
}
