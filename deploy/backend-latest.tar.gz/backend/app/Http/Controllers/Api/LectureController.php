<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Attendance;
use App\Models\Assignment;
use App\Models\AssignmentSubmission;
use App\Models\ClassAnnouncement;
use App\Models\ClassModel;
use App\Models\LectureJournal;
use App\Models\LectureMaterial;
use App\Models\AppNotification;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\ValidationException;

class LectureController extends Controller
{
    // =============================================
    // JURNAL PERKULIAHAN
    // =============================================

    /**
     * GET /lectures/{class} — detail kelas (dipakai ClassDetailView)
     */
    public function show(ClassModel $class): JsonResponse
    {
        $this->authorizeClassView($class);
        $class->load(['course', 'semester', 'lecturer', 'room', 'schedules.room'])
              ->loadCount('members');
        return response()->json($class);
    }

    public function memberList(ClassModel $class): JsonResponse
    {
        $this->authorizeClassView($class);

        // Ambil dari class_members (sudah sync dari KRS)
        $members = $class->members()->with('student:id,nim,name')->orderBy('id')->get();

        // Fallback: ambil dari KRS jika class_members kosong
        if ($members->isEmpty()) {
            $members = \App\Models\KrsDetail::where('class_id', $class->id)
                ->where('status', 'AKTIF')
                ->with(['krs.student:id,nim,name'])
                ->get()
                ->map(fn($d) => (object)[
                    'student_id' => $d->krs?->student_id,
                    'student'    => $d->krs?->student,
                ])
                ->filter(fn($m) => $m->student_id)
                ->values();
        }

        $studentId = auth()->user()->student?->id;
        if ($studentId) {
            $members = $members->where('student_id', $studentId)->values();
        }

        return response()->json($members);
    }

    public function journalList(ClassModel $class): JsonResponse
    {
        $this->authorizeClassView($class);

        $journals = LectureJournal::where('class_id', $class->id)
            ->withCount([
                'attendances',
                'attendances as present_count' => fn ($query) => $query->where('status', 'HADIR'),
            ])
            ->orderBy('meeting_number')
            ->get()
            ->each(function (LectureJournal $journal): void {
                $journal->setAttribute(
                    'photo_url',
                    $journal->photo_path
                        ? url(Storage::disk('public')->url($journal->photo_path))
                        : null
                );
            });
        return response()->json($journals);
    }

    public function storeJournal(Request $request, ClassModel $class): JsonResponse
    {
        $this->authorizeClassManage($class);

        $validated = $request->validate([
            'meeting_number'    => 'required|integer|min:1|max:16',
            'meeting_date'      => 'required|date',
            'topic'             => 'required|string|max:255',
            'description'       => 'nullable|string',
            'learning_activity' => 'nullable|string',
            'status'            => 'nullable|in:PLANNED,COMPLETED,CANCELLED',
            'latitude'          => 'nullable|numeric|between:-90,90',
            'longitude'         => 'nullable|numeric|between:-180,180',
        ]);

        $validated['class_id'] = $class->id;
        $validated['lecturer_id'] = $class->lecturer_id;

        // Upload foto jika ada
        if ($request->hasFile('photo')) {
            $request->validate(['photo' => 'image|mimes:jpeg,png,webp|max:5120']);
            $validated['photo_path'] = $request->file('photo')->store('journals', 'public');
        }

        $journal = LectureJournal::updateOrCreate(
            ['class_id' => $class->id, 'meeting_number' => $validated['meeting_number']],
            $validated
        );

        return response()->json(['message' => 'Jurnal berhasil disimpan.', 'data' => $journal], 201);
    }

    /** Ambil data pertemuan dari RPS/RPKPS untuk auto-fill jurnal */
    public function getFromRps(ClassModel $class): JsonResponse
    {
        $this->authorizeClassView($class);

        $courseIds = $class->offeredCourses()->pluck('courses.id')
            ->push($class->course_id)
            ->filter()
            ->unique()
            ->values();

        $documents = \App\Models\Rpkps::query()
            ->with(['course:id,code,name', 'weeklyPlans'])
            ->whereIn('course_id', $courseIds)
            ->whereIn('status', ['DISETUJUI', 'DIKUNCI', 'DIARSIPKAN'])
            ->orderByDesc('updated_at')
            ->get()
            ->groupBy('course_id')
            ->map(function ($items) use ($class) {
                return $items->sortByDesc(fn ($item) => sprintf(
                    '%d%d%010d',
                    (int) $item->semester_id === (int) $class->semester_id,
                    (int) $item->lecturer_id === (int) $class->lecturer_id,
                    $item->updated_at?->timestamp ?? 0,
                ))->first();
            })
            ->values();

        if ($documents->isEmpty()) {
            return response()->json(['message' => 'Tidak ada RPS yang disetujui untuk mata kuliah ini.', 'plans' => []], 404);
        }

        $sources = $documents->map(function ($rpkps) {
            return [
                'id' => $rpkps->id,
                'rpkps_code' => $rpkps->code,
                'course_id' => $rpkps->course_id,
                'course_code' => $rpkps->course?->code,
                'course_name' => $rpkps->course?->name,
                'semester_id' => $rpkps->semester_id,
                'plans' => $rpkps->weeklyPlans
                    ->sortBy('week_number')
                    ->values()
                    ->map(fn ($week) => [
                        'id' => $week->id,
                        'meeting_number' => $week->week_number,
                        'topic' => $week->sub_cpmk ?: $week->learning_material ?: '',
                        'sub_cpmk' => $week->sub_cpmk ?? '',
                        'description' => $week->learning_material ?? '',
                        'learning_activity' => is_array($week->methods)
                            ? implode(', ', $week->methods)
                            : ($week->methods ?? ''),
                    ])->all(),
            ];
        })->values();

        $primary = $sources->firstWhere('course_id', $class->course_id) ?? $sources->first();

        return response()->json([
            'rpkps_code' => $primary['rpkps_code'],
            'plans' => $primary['plans'],
            'sources' => $sources,
        ]);
    }

    // =============================================
    // PRESENSI
    // =============================================

    public function attendanceList(LectureJournal $journal): JsonResponse
    {
        $class = $journal->class_;
        $this->authorizeClassView($class);

        $attendances = Attendance::where('journal_id', $journal->id)
            ->when(auth()->user()->student?->id, fn ($query, $studentId) => $query->where('student_id', $studentId))
            ->with('student:id,nim,name')
            ->get();
        return response()->json($attendances);
    }

    public function saveAttendance(Request $request, LectureJournal $journal): JsonResponse
    {
        $class = $journal->class_;
        $this->authorizeClassManage($class);

        $validated = $request->validate([
            'attendances'             => 'required|array|min:1',
            'attendances.*.student_id'=> 'required|integer|distinct|exists:students,id',
            'attendances.*.status'    => 'required|in:HADIR,IZIN,SAKIT,ALFA',
        ]);

        $allowedStudentIds = $this->classStudentIds($class);
        $submittedStudentIds = collect($validated['attendances'])->pluck('student_id')->map(fn ($id) => (int) $id);
        $invalidStudentIds = $submittedStudentIds->diff($allowedStudentIds);
        if ($invalidStudentIds->isNotEmpty()) {
            throw ValidationException::withMessages([
                'attendances' => 'Presensi hanya dapat diisi untuk mahasiswa yang terdaftar pada kelas ini.',
            ]);
        }

        DB::transaction(function () use ($journal, $validated) {
            foreach ($validated['attendances'] as $a) {
                $attendance = Attendance::firstOrNew([
                    'journal_id' => $journal->id,
                    'student_id' => $a['student_id'],
                ]);
                $attendance->status = $a['status'];
                $attendance->method = 'MANUAL';
                $attendance->checked_in_at ??= now();
                $attendance->save();
            }
        });

        return response()->json(['message' => 'Presensi berhasil disimpan.']);
    }

    // =============================================
    // MATERI
    // =============================================

    public function materialList(ClassModel $class): JsonResponse
    {
        $this->authorizeClassView($class);
        return response()->json(
            LectureMaterial::where('class_id', $class->id)->orderByDesc('created_at')->get()
        );
    }

    public function storeMaterial(Request $request, ClassModel $class): JsonResponse
    {
        $validated = $request->validate([
            'journal_id'   => 'nullable|exists:lecture_journals,id',
            'title'        => 'required|string|max:255',
            'description'  => 'nullable|string',
            'file_url'     => 'nullable|string|max:500',
            'is_published' => 'boolean',
        ]);
        $validated['class_id'] = $class->id;

        $material = LectureMaterial::create($validated);
        if (!empty($validated['is_published'])) {
            $this->notifyClassStudents($class, 'Materi Baru', "Materi \"{$material->title}\" telah dipublikasikan.");
        }
        return response()->json(['message' => 'Materi berhasil ditambahkan.', 'data' => $material], 201);
    }

    public function destroyMaterial(LectureMaterial $material): JsonResponse
    {
        $material->delete();
        return response()->json(['message' => 'Materi berhasil dihapus.']);
    }

    // =============================================
    // TUGAS
    // =============================================

    public function assignmentList(ClassModel $class): JsonResponse
    {
        $this->authorizeClassView($class);
        return response()->json(
            Assignment::where('class_id', $class->id)
                ->withCount('submissions')
                ->orderByDesc('created_at')->get()
        );
    }

    public function storeAssignment(Request $request, ClassModel $class): JsonResponse
    {
        $validated = $request->validate([
            'title'        => 'required|string|max:255',
            'description'  => 'nullable|string',
            'instructions' => 'nullable|string',
            'type'         => 'nullable|in:INDIVIDU,KELOMPOK',
            'due_date'     => 'nullable|date',
            'max_score'    => 'nullable|integer|min:1',
            'is_published' => 'boolean',
            'allow_late'   => 'boolean',
        ]);
        $validated['class_id'] = $class->id;

        $assignment = Assignment::create($validated);
        if (!empty($validated['is_published'])) {
            $this->notifyClassStudents($class, 'Tugas Baru', "Tugas \"{$assignment->title}\" telah dipublikasikan.");
        }
        return response()->json(['message' => 'Tugas berhasil dibuat.', 'data' => $assignment], 201);
    }

    public function submitAssignment(Request $request, Assignment $assignment): JsonResponse
    {
        $request->validate([
            'content'  => 'nullable|string',
            'file_url' => 'nullable|string|max:500',
        ]);

        $student = auth()->user()->student;
        if (!$student) return response()->json(['message' => 'Akun bukan mahasiswa.'], 403);

        $submission = AssignmentSubmission::updateOrCreate(
            ['assignment_id' => $assignment->id, 'student_id' => $student->id],
            ['content' => $request->content, 'file_url' => $request->file_url, 'submitted_at' => now()]
        );
        $assignment->loadMissing('class_.lecturer');
        if ($assignment->class_?->lecturer?->user_id) {
            AppNotification::send($assignment->class_->lecturer->user_id, 'Pengumpulan Tugas Baru',
                "Mahasiswa {$student->name} mengumpulkan tugas \"{$assignment->title}\".", 'info', '/akademik/kelas');
        }

        return response()->json(['message' => 'Tugas berhasil dikumpulkan.', 'data' => $submission]);
    }

    public function gradeSubmission(Request $request, AssignmentSubmission $submission): JsonResponse
    {
        $request->validate(['score' => 'required|numeric|min:0', 'feedback' => 'nullable|string']);
        $submission->update([
            'score' => $request->score, 'feedback' => $request->feedback,
            'graded_at' => now(), 'graded_by' => auth()->id(),
        ]);
        $submission->loadMissing('student', 'assignment');
        if ($submission->student?->user_id) {
            AppNotification::send($submission->student->user_id, 'Tugas Dinilai',
                "Tugas \"{$submission->assignment?->title}\" telah dinilai.".($request->feedback ? " Feedback: {$request->feedback}" : ''),
                'success', '/akademik/kelas');
        }
        return response()->json(['message' => 'Nilai berhasil disimpan.']);
    }

    // =============================================
    // PENGUMUMAN
    // =============================================

    public function announcementList(ClassModel $class): JsonResponse
    {
        $this->authorizeClassView($class);
        return response()->json(
            ClassAnnouncement::where('class_id', $class->id)->with('user:id,name')->orderByDesc('created_at')->get()
        );
    }

    public function storeAnnouncement(Request $request, ClassModel $class): JsonResponse
    {
        $validated = $request->validate(['title' => 'required|string', 'content' => 'required|string']);
        $ann = ClassAnnouncement::create(array_merge($validated, ['class_id' => $class->id, 'user_id' => auth()->id()]));
        $this->notifyClassStudents($class, 'Pengumuman Kelas Baru', $ann->title);
        return response()->json(['message' => 'Pengumuman berhasil dibuat.', 'data' => $ann], 201);
    }

    public function destroyJournal(LectureJournal $journal): JsonResponse
    {
        $this->authorizeClassManage($journal->class_);
        $journal->attendances()->delete();
        $journal->delete();
        return response()->json(['message' => 'Jurnal pertemuan berhasil dihapus.']);
    }

    public function updateJournal(Request $request, LectureJournal $journal): JsonResponse
    {
        $this->authorizeClassManage($journal->class_);
        $validated = $request->validate([
            'meeting_number'    => 'sometimes|integer|min:1|max:16',
            'meeting_date'      => 'sometimes|date',
            'topic'             => 'sometimes|string|max:255',
            'description'       => 'nullable|string',
            'learning_activity' => 'nullable|string',
            'status'            => 'nullable|in:PLANNED,COMPLETED,CANCELLED',
            'latitude'          => 'nullable|numeric|between:-90,90',
            'longitude'         => 'nullable|numeric|between:-180,180',
        ]);
        $journal->update($validated);
        return response()->json(['message' => 'Jurnal berhasil diupdate.', 'data' => $journal->fresh()]);
    }

    public function destroyAssignment(Assignment $assignment): JsonResponse
    {
        $assignment->submissions()->delete();
        $assignment->delete();
        return response()->json(['message' => 'Tugas berhasil dihapus.']);
    }

    public function updateAssignment(Request $request, Assignment $assignment): JsonResponse
    {
        $wasPublished = (bool) $assignment->is_published;
        $validated = $request->validate([
            'title'        => 'sometimes|string|max:255',
            'description'  => 'nullable|string',
            'instructions' => 'nullable|string',
            'due_date'     => 'nullable|date',
            'max_score'    => 'nullable|integer|min:0',
            'is_published' => 'boolean',
        ]);
        $assignment->update($validated);
        if (!$wasPublished && !empty($validated['is_published'])) {
            $this->notifyClassStudents($assignment->class_, 'Tugas Baru',
                "Tugas \"{$assignment->title}\" telah dipublikasikan.");
        }
        return response()->json(['message' => 'Tugas berhasil diupdate.', 'data' => $assignment->fresh()]);
    }

    public function destroyAnnouncement(ClassAnnouncement $announcement): JsonResponse
    {
        $announcement->delete();
        return response()->json(['message' => 'Pengumuman berhasil dihapus.']);
    }

    public function updateAnnouncement(Request $request, ClassAnnouncement $announcement): JsonResponse
    {
        $validated = $request->validate([
            'title'   => 'sometimes|string|max:255',
            'content' => 'sometimes|string',
        ]);
        $announcement->update($validated);
        return response()->json(['message' => 'Pengumuman berhasil diupdate.', 'data' => $announcement->fresh()]);
    }

    private function notifyClassStudents(ClassModel $class, string $title, string $message): void
    {
        $class->loadMissing('members.student');
        foreach ($class->members as $member) {
            if ($member->student?->user_id) {
                AppNotification::send($member->student->user_id, $title, $message, 'info', '/akademik/kelas/'.$class->id);
            }
        }
    }

    private function authorizeClassView(ClassModel $class): void
    {
        $user = auth()->user();
        if ($user->hasRole('SUPER_ADMIN') || $user->hasRole('ADMIN_AKADEMIK')) {
            return;
        }

        $lecturer = $user->lecturer;
        if ($lecturer) {
            $isAssigned = (int) $class->lecturer_id === (int) $lecturer->id
                || $class->lecturers()->whereKey($lecturer->id)->exists();
            $hasProgramScope = $lecturer->positions()
                ->where('is_active', true)
                ->whereIn('position_code', ['KAPRODI', 'SEKPRODI'])
                ->where('scope_type', 'study_program')
                ->where('scope_id', $class->study_program_id)
                ->exists();
            if ($isAssigned || $hasProgramScope) {
                return;
            }
        }

        $studentId = $user->student?->id;
        if ($studentId && $this->classStudentIds($class)->contains((int) $studentId)) {
            return;
        }

        abort(403, 'Anda tidak memiliki akses ke kelas ini.');
    }

    private function authorizeClassManage(ClassModel $class): void
    {
        if (auth()->user()->student) {
            abort(403, 'Mahasiswa tidak diizinkan mengubah data kelas.');
        }

        $this->authorizeClassView($class);
    }

    private function classStudentIds(ClassModel $class)
    {
        $memberIds = $class->members()->pluck('student_id');
        $krsStudentIds = \App\Models\KrsDetail::query()
            ->where('class_id', $class->id)
            ->where('krs_details.status', 'AKTIF')
            ->whereHas('krs', fn ($query) => $query
                ->where('student_id', auth()->user()->student?->id)
                ->where('status', 'APPROVED'))
            ->join('krs', 'krs.id', '=', 'krs_details.krs_id')
            ->pluck('krs.student_id');

        return $memberIds->merge($krsStudentIds)->map(fn ($id) => (int) $id)->unique()->values();
    }
}
