<?php

namespace App\Exports;

use App\Models\Rpkps;
use Maatwebsite\Excel\Concerns\WithMultipleSheets;
use Maatwebsite\Excel\Concerns\WithTitle;
use Maatwebsite\Excel\Concerns\FromArray;

class RpkpsWorkbookExport implements WithMultipleSheets
{
    public function __construct(private ?Rpkps $rpkps = null, private bool $template = false) {}

    public function sheets(): array
    {
        $names = ['PETUNJUK', 'IDENTITAS', 'CPMK', 'SUB_CPMK', 'BAHAN_KAJIAN', 'RENCANA_MINGGUAN', 'ASESMEN', 'INSTRUMEN', 'RUBRIK', 'SKALA_NILAI', 'REFERENSI'];
        return array_map(fn ($name) => new RpkpsSheet($name, $this->rows($name)), $names);
    }

    private function rows(string $name): array
    {
        if ($this->template) {
            return match ($name) {
                'PETUNJUK' => [['Template Import RPKPS/RPS'], ['CPL tidak disertakan karena diambil otomatis dari kurikulum.'], ['Isi sheet selain PETUNJUK menggunakan baris pertama sebagai header. Hapus contoh sebelum import.']],
                'IDENTITAS' => [['course_id','curriculum_id','academic_year_id','semester_id','lecturer_id','coordinator_id','course_description','course_urgency','course_scope','course_position','prerequisites'], ['', '', '', '', '', '', '', '', '', '', '']],
                'CPMK' => [['code','description','order'], ['CPMK-01','Contoh capaian pembelajaran mata kuliah',1]],
                'SUB_CPMK' => [['cpmk_code','code','description','order'], ['CPMK-01','SUB-01','Contoh sub-CPMK',1]],
                'BAHAN_KAJIAN' => [['topic','subtopics','order'], ['Contoh bahan kajian','Subtopik',1]],
                'RENCANA_MINGGUAN' => [['week_number','sub_cpmk','indicators','learning_material','methods','offline_learning','online_learning','lecturer_activity','student_activity','assessment_form','assessment_criteria','media','duration','weight'], [1,'SUB-01','Indikator','Materi','Ceramah|Diskusi','','','Aktivitas dosen','Aktivitas mahasiswa','Tes','Kriteria','LCD','2x50 menit',5]],
                'ASESMEN' => [['name','weight','description','order','final_grade_formula'], ['Tugas',20,'Deskripsi',1,'']],
                'INSTRUMEN' => [['assessment_name','sub_cpmk','instrument_name','instrument_type','technique','cognitive_level','affective_level','psychomotor_level','item_numbers','weight','timing','description','order'], ['Tugas','SUB-01','Contoh instrumen','Non-tes','Observasi','','','','',20,'Minggu 1','',1]],
                'RUBRIK' => [['assessment_name','title','criteria','weight','excellent','good','fair','poor','very_poor','order'], ['Tugas','Rubrik tugas','Kriteria',100,'Sangat baik','Baik','Cukup','Kurang','Sangat kurang',1]],
                'SKALA_NILAI' => [['min_score','max_score','letter','grade_point','order'], [85,100,'A',4,1]],
                'REFERENSI' => [['type','category','title','author','year','publisher','isbn_doi','url','order'], ['Utama','Buku','Judul referensi','Penulis','2026','Penerbit','','',1]],
            };
        }

        $r = $this->rpkps;
        return match ($name) {
            'PETUNJUK' => [['Export RPKPS/RPS', $r?->code ?? '']],
            'IDENTITAS' => [['course_id','curriculum_id','academic_year_id','semester_id','lecturer_id','coordinator_id','course_description','course_urgency','course_scope','course_position','prerequisites'], [$r->course_id,$r->curriculum_id,$r->academic_year_id,$r->semester_id,$r->lecturer_id,$r->coordinator_id,$r->course_description,$r->course_urgency,$r->course_scope,$r->course_position,$r->prerequisites]],
            'CPMK' => array_merge([['code','description','order']], $r->cpmks->map(fn ($x) => [$x->code,$x->description,$x->order])->all()),
            'SUB_CPMK' => array_merge([['cpmk_code','code','description','order']], $r->cpmks->flatMap(fn ($c) => $c->subCpmks->map(fn ($x) => [$c->code,$x->code,$x->description,$x->order]))->all()),
            'BAHAN_KAJIAN' => array_merge([['topic','subtopics','order']], $r->learningMaterials->map(fn ($x) => [$x->topic,$x->subtopics,$x->order])->all()),
            'RENCANA_MINGGUAN' => array_merge([['week_number','sub_cpmk','indicators','learning_material','methods','offline_learning','online_learning','lecturer_activity','student_activity','assessment_form','assessment_criteria','media','duration','weight']], $r->weeklyPlans->map(fn ($x) => [$x->week_number,$x->sub_cpmk,$x->indicators,$x->learning_material,is_array($x->methods)?implode('|',$x->methods):$x->methods,$x->offline_learning,$x->online_learning,$x->lecturer_activity,$x->student_activity,$x->assessment_form,$x->assessment_criteria,$x->media,$x->duration,$x->weight])->all()),
            'ASESMEN' => array_merge([['name','weight','description','order','final_grade_formula']], $r->assessments->map(fn ($x) => [$x->name,$x->weight,$x->description,$x->order,$r->final_grade_formula])->all()),
            'INSTRUMEN' => array_merge([['assessment_name','sub_cpmk','instrument_name','instrument_type','technique','cognitive_level','affective_level','psychomotor_level','item_numbers','weight','timing','description','order']], $r->assessmentInstruments->map(fn ($x) => [$x->assessment?->name,$x->sub_cpmk,$x->instrument_name,$x->instrument_type,$x->technique,$x->cognitive_level,$x->affective_level,$x->psychomotor_level,$x->item_numbers,$x->weight,$x->timing,$x->description,$x->order])->all()),
            'RUBRIK' => array_merge([['assessment_name','title','criteria','weight','excellent','good','fair','poor','very_poor','order']], $r->rubrics->map(fn ($x) => [$x->assessment?->name,$x->title,$x->criteria,$x->weight,$x->excellent,$x->good,$x->fair,$x->poor,$x->very_poor,$x->order])->all()),
            'SKALA_NILAI' => array_merge([['min_score','max_score','letter','grade_point','order']], $r->gradeScales->map(fn ($x) => [$x->min_score,$x->max_score,$x->letter,$x->grade_point,$x->order])->all()),
            'REFERENSI' => array_merge([['type','category','title','author','year','publisher','isbn_doi','url','order']], $r->references->map(fn ($x) => [$x->type,$x->category,$x->title,$x->author,$x->year,$x->publisher,$x->isbn_doi,$x->url,$x->order])->all()),
        };
    }
}

class RpkpsSheet implements FromArray, WithTitle
{
    public function __construct(private string $title, private array $rows) {}
    public function array(): array { return $this->rows; }
    public function title(): string { return $this->title; }
}
