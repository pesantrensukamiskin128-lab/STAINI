<?php

namespace App\Exports;

use Maatwebsite\Excel\Concerns\FromArray;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithStyles;
use Maatwebsite\Excel\Concerns\WithTitle;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;

class TemplateExport implements FromArray, ShouldAutoSize, WithHeadings, WithStyles, WithTitle
{
    private string $type;

    private const HEADINGS = [
        'courses' => [
            'kode_mk', 'nama_mata_kuliah', 'kode_prodi',
            'rumpun_mata_kuliah', 'sks_teori', 'sks_praktik',
            'semester', 'jenis', 'status',
        ],
        'lecturers' => [
            'nidn', 'nuptk', 'nip', 'gelar_depan', 'nama_lengkap', 'gelar_belakang',
            'kode_prodi', 'jenis_kelamin', 'tempat_lahir', 'tanggal_lahir',
            'email', 'no_hp', 'jabatan_akademik', 'status_kepegawaian', 'status',
        ],
        'students' => [
            'NIM', 'Nama', 'Tempat Lahir', 'Tanggal Lahir', 'Jenis Kelamin',
            'NIK', 'Agama', 'NISN', 'Jalur Pendaftaran', 'NPWP',
            'Kewarganegaraan', 'Jenis Pendaftaran', 'Tanggal Masuk Kuliah',
            'Mulai Semester', 'Jalan', 'RT', 'RW', 'Nama Dusun', 'Kelurahan',
            'Kecamatan', 'Kode Pos', 'Jenis Tinggal', 'Alat Transportasi',
            'Telp Rumah', 'No HP', 'Email', 'Terima KPS', 'No KPS',
            'NIK Ayah', 'Nama Ayah', 'Tanggal Lahir Ayah', 'Pendidikan Ayah',
            'Pekerjaan Ayah', 'Penghasilan Ayah', 'NIK Ibu', 'Nama Ibu',
            'Tanggal Lahir Ibu', 'Pendidikan Ibu', 'Pekerjaan Ibu',
            'Penghasilan Ibu', 'Nama Wali', 'Tanggal Lahir Wali',
            'Pendidikan Wali', 'Pekerjaan Wali', 'Penghasilan Wali',
            'Kode Prodi', 'Nama Prodi', 'SKS Diakui', 'Kode PT Asal',
            'Nama PT Asal', 'Kode Prodi Asal', 'Nama Prodi Asal',
            'Jenis Pembiayaan', 'Jumlah Biaya Masuk',
        ],
        'staff' => [
            'nip', 'nama_lengkap', 'jenis_kelamin',
            'tempat_lahir', 'tanggal_lahir',
            'email', 'no_hp', 'jabatan', 'unit_bagian',
            'status_kepegawaian', 'status',
        ],
        'krs' => [
            'nim', 'nama_mahasiswa', 'kode_prodi', 'id_semester', 'nama_semester',
            'kode_mata_kuliah', 'id_kelas', 'nama_kelas', 'status_krs', 'total_sks',
        ],
    ];

    /** Baris contoh agar user paham format yang diharapkan */
    private const EXAMPLES = [
        'courses' => [['TI999', 'Contoh Mata Kuliah', 'TI', 'Mata Kuliah Keahlian', 2, 1, 1, 'Wajib', 'Aktif']],
        'lecturers' => [['1234567890', '', '', 'Dr.', 'Nama Dosen Contoh', 'S.Kom., M.T.', 'TI', 'Laki-laki', 'Bandung', '1980-01-15', 'dosen@example.com', '08123456789', 'Asisten Ahli', 'Tetap', 'Aktif']],
        'students' => [[
            '2024001001', 'Nama Mahasiswa Contoh', 'Jakarta', '2002-05-20', 'L',
            '3200000000000000', '1', '0040000000', '1', '', 'ID', '1',
            '2024-08-20', '20241', 'Jl. Contoh No. 1', '01', '02',
            'Dusun Contoh', 'Kelurahan Contoh', 'Kecamatan Contoh', '40123',
            '1', '1', '021000000', '08198765432', 'mhs@example.com', '0', '',
            '', 'Nama Ayah Contoh', '1970-01-01', '2', '1', '5',
            '', 'Nama Ibu Contoh', '1975-01-01', '2', '2', '5',
            'Nama Wali Contoh', '1980-01-01', '2', '3', '5',
            'TI', 'Teknik Informatika', '', '', '', '', '', '1', '5000000',
        ]],
        'staff' => [['198001012010011001', 'Nama Staff Contoh', 'Laki-laki', 'Surabaya', '1980-01-01', 'staff@example.com', '08111111111', 'Kepala Bagian', 'Akademik', 'Tetap', 'Aktif']],
        'krs' => [
            ['2026001001', 'Nama Mahasiswa Contoh', 'PAI', '', '2026/2027 Ganjil', 'PAI101', 101, 'A', 'DRAFT', ''],
            ['2026001001', 'Nama Mahasiswa Contoh', 'PAI', '', '2026/2027 Ganjil', 'PAI102', 102, 'A', 'DRAFT', ''],
        ],
    ];

    public function __construct(string $type)
    {
        $this->type = $type;
    }

    public function title(): string
    {
        return 'Template';
    }

    public function array(): array
    {
        return self::EXAMPLES[$this->type] ?? [];
    }

    public function headings(): array
    {
        return self::HEADINGS[$this->type] ?? [];
    }

    public function styles(Worksheet $sheet): array
    {
        return [
            1 => [
                'font' => ['bold' => true, 'color' => ['rgb' => 'FFFFFF']],
                'fill' => ['fillType' => Fill::FILL_SOLID, 'startColor' => ['rgb' => '16A34A']],
                'alignment' => ['horizontal' => Alignment::HORIZONTAL_CENTER],
            ],
            2 => [
                'font' => ['italic' => true, 'color' => ['rgb' => '6B7280']],
            ],
        ];
    }
}
