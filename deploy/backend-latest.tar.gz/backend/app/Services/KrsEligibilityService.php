<?php

namespace App\Services;

use App\Models\Invoice;
use App\Models\InvoiceItem;
use App\Models\Semester;
use App\Models\Student;
use DomainException;

class KrsEligibilityService
{
    public function __construct(private readonly FeeStructureResolver $feeStructures) {}

    public function evaluate(Student $student, Semester $semester): array
    {
        $today = now()->startOfDay();
        $periodConfigured = (bool) ($semester->krs_start && $semester->krs_end);
        $periodOpen = ! $periodConfigured || (
            $today->greaterThanOrEqualTo($semester->krs_start->startOfDay())
            && $today->lessThanOrEqualTo($semester->krs_end->endOfDay())
        );

        $requiredStructures = $this->feeStructures->resolve($student, $semester)
            ->filter(fn ($structure) => (bool) $structure->feeType?->is_mandatory);
        $requiredFeeTypeIds = $requiredStructures->pluck('fee_type_id')->map(fn ($id) => (int) $id)->unique()->values();

        // Data migrasi lama dapat memiliki tagihan wajib sebelum struktur biaya dikonfigurasi.
        if ($requiredFeeTypeIds->isEmpty()) {
            $requiredFeeTypeIds = InvoiceItem::query()
                ->whereHas('invoice', fn ($query) => $query
                    ->where('student_id', $student->id)
                    ->where('semester_id', $semester->id)
                    ->where('status', '!=', 'CANCELLED'))
                ->whereHas('feeType', fn ($query) => $query->where('is_mandatory', true))
                ->pluck('fee_type_id')
                ->map(fn ($id) => (int) $id)
                ->unique()
                ->values();
        }

        $invoices = Invoice::query()
            ->with(['items.feeType', 'payments'])
            ->where('student_id', $student->id)
            ->where('semester_id', $semester->id)
            ->where('status', '!=', 'CANCELLED')
            ->get();

        $coveredFeeTypeIds = $invoices
            ->flatMap(fn (Invoice $invoice) => $invoice->items
                ->whereIn('fee_type_id', $requiredFeeTypeIds->all())
                ->pluck('fee_type_id'))
            ->map(fn ($id) => (int) $id)
            ->unique();

        $missingFeeTypeIds = $requiredFeeTypeIds->diff($coveredFeeTypeIds)->values();
        $blockingInvoices = $invoices
            ->filter(function (Invoice $invoice) use ($requiredFeeTypeIds): bool {
                $requiredItems = $invoice->items->whereIn('fee_type_id', $requiredFeeTypeIds->all());
                if ($requiredItems->isEmpty()) {
                    return false;
                }

                $sppAmount = $requiredItems
                    ->filter(fn (InvoiceItem $item) => $item->feeType?->code === 'SPP')
                    ->sum('amount');
                $otherRequiredAmount = $requiredItems
                    ->reject(fn (InvoiceItem $item) => $item->feeType?->code === 'SPP')
                    ->sum('amount');
                $minimumSppPayment = $sppAmount > 0 ? (int) ceil($sppAmount / 6) : 0;
                $minimumPayment = $otherRequiredAmount + $minimumSppPayment;
                $discounts = (float) $invoice->discount_amount + (float) $invoice->scholarship_amount;
                $minimumPayment = max(0, $minimumPayment - $discounts);
                $verifiedPayment = max(
                    (float) $invoice->paid_amount,
                    (float) $invoice->payments->where('status', 'VERIFIED')->sum('amount')
                );

                return $verifiedPayment < $minimumPayment;
            })
            ->map(fn (Invoice $invoice) => [
                'id' => $invoice->id,
                'invoice_number' => $invoice->invoice_number,
                'status' => $invoice->status,
                'due_date' => $invoice->due_date,
                'total_amount' => $invoice->total_amount,
                'paid_amount' => $invoice->paid_amount,
            ])
            ->values();

        $financeConfigured = $requiredFeeTypeIds->isNotEmpty();
        $financeClear = $financeConfigured && $missingFeeTypeIds->isEmpty() && $blockingInvoices->isEmpty();

        return [
            'semester_id' => $semester->id,
            'period' => [
                'configured' => $periodConfigured,
                'is_open' => $periodOpen,
                'start_date' => $semester->krs_start?->format('Y-m-d'),
                'end_date' => $semester->krs_end?->format('Y-m-d'),
                'message' => ! $periodConfigured
                    ? 'Periode KRS belum dikonfigurasi; akses sementara tetap dibuka.'
                    : ($periodOpen ? 'Periode pengisian KRS sedang dibuka.' : 'Periode pengisian KRS sedang ditutup.'),
            ],
            'finance' => [
                'configured' => $financeConfigured,
                'is_clear' => $financeClear,
                'required_fee_type_ids' => $requiredFeeTypeIds->all(),
                'missing_fee_type_ids' => $missingFeeTypeIds->all(),
                'blocking_invoices' => $blockingInvoices,
                'message' => ! $financeConfigured
                    ? 'Struktur/tagihan biaya wajib semester ini belum dikonfigurasi.'
                    : ($missingFeeTypeIds->isNotEmpty()
                        ? 'Tagihan wajib semester ini belum lengkap.'
                        : ($blockingInvoices->isNotEmpty()
                            ? 'Pembayaran minimum tagihan wajib semester ini belum terpenuhi (SPP minimal 1/6 nominal semester).'
                            : 'Kewajiban keuangan untuk KRS sudah terpenuhi.')),
            ],
            'can_submit' => $periodOpen && $financeClear,
        ];
    }

    public function assertPeriodOpen(Student $student, Semester $semester): void
    {
        $eligibility = $this->evaluate($student, $semester);
        if (! $eligibility['period']['is_open']) {
            throw new DomainException($eligibility['period']['message']);
        }
    }

    public function assertFinanciallyClear(Student $student, Semester $semester): void
    {
        $eligibility = $this->evaluate($student, $semester);
        if (! $eligibility['finance']['is_clear']) {
            throw new DomainException($eligibility['finance']['message']);
        }
    }
}
