<?php

namespace App\Imports;

use App\Models\Lecturer;
use App\Models\AcademicYear;
use App\Models\Student;
use App\Models\StudyProgram;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Support\Facades\Hash;
use Maatwebsite\Excel\Concerns\SkipsErrors;
use Maatwebsite\Excel\Concerns\SkipsOnError;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithBatchInserts;
use Maatwebsite\Excel\Concerns\WithChunkReading;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Maatwebsite\Excel\Concerns\WithValidation;

class StudentImport implements SkipsOnError, ToModel, WithBatchInserts, WithChunkReading, WithHeadingRow, WithValidation
{
    use SkipsErrors;

    private array $programCache = [];

    private array $advisorCache = [];

    public function model(array $row): ?Student
    {
        $nim = trim($row['nim'] ?? '');
        $name = trim($row['nama'] ?? '');
        if (! $nim || ! $name) {
            return null;
        }

        $programId = $this->resolveProgramId($row['kode_prodi'] ?? '');
        if (! $programId) {
            return null;
        }

        // Buat akun user otomatis
        $email = ! empty(trim($row['email'] ?? ''))
            ? trim($row['email'])
            : "{$nim}@student.stai-aljawami.ac.id";

        $user = User::firstOrCreate(
            ['username' => $nim],
            ['name' => $name, 'email' => $email, 'password' => Hash::make($nim)]
        );
        if ($user->wasRecentlyCreated) {
            $user->assignRole('MAHASISWA');
        }

        $genderMap = ['laki-laki' => 'L', 'perempuan' => 'P', 'l' => 'L', 'p' => 'P'];
        $genderRaw = strtolower(trim($row['jenis_kelamin'] ?? ''));
        $genderMap += ['male' => 'L', 'female' => 'P', 'm' => 'L', 'f' => 'P'];
        $gender = $genderMap[$genderRaw] ?? null;

        $birthDate = $this->parseDate($row['tanggal_lahir'] ?? null);
        $entryYear = $this->entryYear($row);
        $academicYearId = $this->resolveAcademicYearId($entryYear);

        $status = in_array($row['status'] ?? '', Student::STATUSES, true) ? $row['status'] : 'Aktif';
        $classType = strtoupper(trim($row['jenis_kelas'] ?? 'REGULER'));
        if (! in_array($classType, Student::CLASS_TYPES, true)) {
            $classType = 'REGULER';
        }

        return Student::updateOrCreate(
            ['nim' => $nim],
            [
                'user_id' => $user->id,
                'study_program_id' => $programId,
                'academic_year_id' => $academicYearId,
                'advisor_id' => $this->resolveAdvisorId($row['dosen_wali'] ?? ''),
                'name' => $name,
                'gender' => $gender,
                'birth_place' => trim($row['tempat_lahir'] ?? '') ?: null,
                'birth_date' => $birthDate,
                'email' => $email,
                'phone' => trim($row['no_hp'] ?? '') ?: null,
                'home_phone' => trim($row['telp_rumah'] ?? '') ?: null,
                'entry_year' => $entryYear,
                'status' => $status,
                'class_type' => $classType,
            ]
        );

        $student->profile()->updateOrCreate([], [
            'religion' => $row['agama'] ?? null,
            'nik' => $row['nik'] ?? null,
            'nisn' => $row['nisn'] ?? null,
            'nationality' => $row['kewarganegaraan'] ?? 'Indonesia',
            'admission_path' => $row['jalur_pendaftaran'] ?? null,
            'npwp' => $row['npwp'] ?? null,
            'registration_type' => $row['jenis_pendaftaran'] ?? null,
            'enrollment_date' => $this->parseDate($row['tanggal_masuk_kuliah'] ?? null),
            'start_semester' => $row['mulai_semester'] ?? null,
            'residence_type' => $row['jenis_tinggal'] ?? null,
            'transport_mode' => $row['alat_transportasi'] ?? null,
            'kps_recipient' => $this->parseBoolean($row['terima_kps'] ?? null),
            'kps_number' => $row['no_kps'] ?? null,
            'financing_type' => $row['jenis_pembiayaan'] ?? null,
            'recognized_credits' => $row['sks_diakui'] ?? null,
            'origin_institution_code' => $row['kode_pt_asal'] ?? null,
            'origin_institution_name' => $row['nama_pt_asal'] ?? null,
            'origin_program_code' => $row['kode_prodi_asal'] ?? null,
            'origin_program_name' => $row['nama_prodi_asal'] ?? null,
            'entry_fee' => $row['jumlah_biaya_masuk'] ?? null,
        ]);

        $student->addresses()->updateOrCreate(['type' => 'Domisili'], [
            'address' => $row['jalan'] ?? null,
            'rt' => $row['rt'] ?? null,
            'rw' => $row['rw'] ?? null,
            'hamlet' => $row['nama_dusun'] ?? null,
            'village' => $row['kelurahan'] ?? null,
            'district' => $row['kecamatan'] ?? null,
            'postal_code' => $row['kode_pos'] ?? null,
        ]);

        $this->upsertParent($student, 'Ayah', $row, 'ayah');
        $this->upsertParent($student, 'Ibu', $row, 'ibu');
        $this->upsertParent($student, 'Wali', $row, 'wali');

        return $student;
    }

    public function rules(): array
    {
        return [
            'nim' => 'required',
            'nama' => 'required',
            'kode_prodi' => 'required',
        ];
    }

    private function entryYear(array $row): ?int
    {
        if (! empty($row['mulai_semester']) && preg_match('/^(\\d{4})/', (string) $row['mulai_semester'], $match)) {
            return (int) $match[1];
        }

        $date = $this->parseDate($row['tanggal_masuk_kuliah'] ?? null);
        return $date?->year;
    }

    private function resolveAcademicYearId(?int $entryYear): ?int
    {
        if (! $entryYear) {
            return null;
        }

        return AcademicYear::whereYear('start_date', $entryYear)->value('id')
            ?? AcademicYear::where('name', 'like', "%{$entryYear}%")->value('id');
    }

    private function parseDate(mixed $value): ?string
    {
        if ($value === null || $value === '') {
            return null;
        }

        try {
            if (is_numeric($value)) {
                return Carbon::create(1899, 12, 30)->addDays((int) $value)->format('Y-m-d');
            }

            return Carbon::parse((string) $value)->format('Y-m-d');
        } catch (\Throwable) {
            return null;
        }
    }

    private function parseBoolean(mixed $value): ?bool
    {
        if ($value === null || $value === '') {
            return null;
        }

        return in_array(strtolower((string) $value), ['1', 'ya', 'yes', 'true'], true);
    }

    private function upsertParent(Student $student, string $relation, array $row, string $key): void
    {
        $name = trim((string) ($row["nama_{$key}"] ?? ''));
        if ($name === '') {
            return;
        }

        $student->parents()->updateOrCreate(['relation' => $relation], [
            'name' => $name,
            'nik' => $row["nik_{$key}"] ?? null,
            'birth_date' => $this->parseDate($row["tanggal_lahir_{$key}"] ?? null),
            'education' => $row["pendidikan_{$key}"] ?? null,
            'occupation' => $row["pekerjaan_{$key}"] ?? null,
            'income' => $row["penghasilan_{$key}"] ?? null,
        ]);
    }

    public function batchSize(): int
    {
        return 100;
    }

    public function chunkSize(): int
    {
        return 200;
    }

    private function resolveProgramId(string $code): ?int
    {
        $code = strtoupper(trim($code));
        if (! $code) {
            return null;
        }

        if (! isset($this->programCache[$code])) {
            $this->programCache[$code] = StudyProgram::where('code', $code)->value('id');
        }

        return $this->programCache[$code];
    }

    private function resolveAdvisorId(string $nidn): ?int
    {
        $nidn = trim($nidn);
        if (! $nidn) {
            return null;
        }

        if (! isset($this->advisorCache[$nidn])) {
            $this->advisorCache[$nidn] = Lecturer::where('nidn', $nidn)->value('id');
        }

        return $this->advisorCache[$nidn];
    }
}
