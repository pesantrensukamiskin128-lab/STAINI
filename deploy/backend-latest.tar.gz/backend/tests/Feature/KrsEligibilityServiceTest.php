<?php

namespace Tests\Feature;

use App\Http\Controllers\Api\FinanceController;
use App\Models\Semester;
use App\Models\Student;
use App\Services\FeeStructureResolver;
use App\Services\KrsEligibilityService;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Tests\TestCase;

class KrsEligibilityServiceTest extends TestCase
{
    protected function setUp(): void
    {
        parent::setUp();
        Carbon::setTestNow('2026-09-17 09:00:00');

        Schema::create('students', function (Blueprint $table): void {
            $table->id();
            $table->unsignedBigInteger('study_program_id');
            $table->unsignedBigInteger('user_id')->nullable();
            $table->unsignedInteger('current_semester')->nullable();
            $table->string('nim');
            $table->string('name');
            $table->string('status')->default('Aktif');
            $table->timestamps();
        });
        Schema::create('semesters', function (Blueprint $table): void {
            $table->id();
            $table->unsignedBigInteger('academic_year_id');
            $table->string('name');
            $table->date('krs_start')->nullable();
            $table->date('krs_end')->nullable();
            $table->timestamps();
        });
        Schema::create('fee_types', function (Blueprint $table): void {
            $table->id();
            $table->string('code');
            $table->string('name');
            $table->boolean('is_active')->default(true);
            $table->boolean('is_mandatory')->default(true);
            $table->boolean('is_recurring')->default(true);
            $table->timestamps();
        });
        Schema::create('fee_structures', function (Blueprint $table): void {
            $table->id();
            $table->unsignedBigInteger('fee_type_id');
            $table->unsignedBigInteger('study_program_id')->nullable();
            $table->unsignedBigInteger('academic_year_id')->nullable();
            $table->unsignedInteger('academic_level')->nullable();
            $table->unsignedBigInteger('amount');
            $table->timestamps();
        });
        Schema::create('invoices', function (Blueprint $table): void {
            $table->id();
            $table->string('invoice_number');
            $table->unsignedBigInteger('student_id');
            $table->unsignedBigInteger('semester_id');
            $table->date('invoice_date');
            $table->date('due_date');
            $table->unsignedBigInteger('total_amount')->default(0);
            $table->unsignedBigInteger('discount_amount')->default(0);
            $table->unsignedBigInteger('scholarship_amount')->default(0);
            $table->unsignedBigInteger('paid_amount')->default(0);
            $table->string('status');
            $table->unsignedBigInteger('created_by')->nullable();
            $table->timestamps();
        });
        Schema::create('invoice_items', function (Blueprint $table): void {
            $table->id();
            $table->unsignedBigInteger('invoice_id');
            $table->unsignedBigInteger('fee_type_id');
            $table->string('description')->nullable();
            $table->unsignedBigInteger('amount');
            $table->timestamps();
        });

        DB::table('students')->insert([
            'id' => 1, 'study_program_id' => 10, 'current_semester' => 3,
            'nim' => 'MHS-001', 'name' => 'Mahasiswa', 'created_at' => now(), 'updated_at' => now(),
        ]);
        DB::table('semesters')->insert([
            'id' => 1, 'academic_year_id' => 20, 'name' => 'Ganjil 2026/2027',
            'krs_start' => '2026-09-10', 'krs_end' => '2026-09-20',
            'created_at' => now(), 'updated_at' => now(),
        ]);
        DB::table('fee_types')->insert([
            'id' => 1, 'code' => 'SPP', 'name' => 'SPP', 'is_active' => true,
            'is_mandatory' => true, 'is_recurring' => true, 'created_at' => now(), 'updated_at' => now(),
        ]);
    }

    protected function tearDown(): void
    {
        Carbon::setTestNow();
        parent::tearDown();
    }

    public function test_resolver_chooses_the_most_specific_structure_per_fee_type(): void
    {
        DB::table('fee_structures')->insert([
            ['id' => 1, 'fee_type_id' => 1, 'study_program_id' => null, 'academic_year_id' => null, 'academic_level' => null, 'amount' => 100000, 'created_at' => now(), 'updated_at' => now()],
            ['id' => 2, 'fee_type_id' => 1, 'study_program_id' => 10, 'academic_year_id' => 20, 'academic_level' => 3, 'amount' => 250000, 'created_at' => now(), 'updated_at' => now()],
        ]);

        $resolved = app(FeeStructureResolver::class)->resolve(Student::findOrFail(1), Semester::findOrFail(1));

        $this->assertCount(1, $resolved);
        $this->assertSame(2, $resolved->first()->id);
        $this->assertSame(250000, (int) $resolved->first()->amount);
    }

    public function test_krs_is_blocked_until_the_mandatory_invoice_is_paid(): void
    {
        DB::table('fee_structures')->insert([
            'fee_type_id' => 1, 'study_program_id' => 10, 'academic_year_id' => 20,
            'academic_level' => 3, 'amount' => 250000, 'created_at' => now(), 'updated_at' => now(),
        ]);

        $service = app(KrsEligibilityService::class);
        $student = Student::findOrFail(1);
        $semester = Semester::findOrFail(1);

        $missingInvoice = $service->evaluate($student, $semester);
        $this->assertFalse($missingInvoice['finance']['is_clear']);
        $this->assertSame([1], $missingInvoice['finance']['missing_fee_type_ids']);

        DB::table('invoices')->insert([
            'id' => 1, 'invoice_number' => 'INV-001', 'student_id' => 1, 'semester_id' => 1,
            'invoice_date' => '2026-09-01', 'due_date' => '2026-09-10', 'total_amount' => 250000,
            'paid_amount' => 250000, 'status' => 'PAID', 'created_at' => now(), 'updated_at' => now(),
        ]);
        DB::table('invoice_items')->insert([
            'invoice_id' => 1, 'fee_type_id' => 1, 'amount' => 250000,
            'created_at' => now(), 'updated_at' => now(),
        ]);

        $paidInvoice = $service->evaluate($student, $semester);
        $this->assertTrue($paidInvoice['finance']['is_clear']);
        $this->assertTrue($paidInvoice['can_submit']);
    }

    public function test_closed_krs_period_is_reported(): void
    {
        DB::table('semesters')->where('id', 1)->update(['krs_end' => '2026-09-16']);

        $result = app(KrsEligibilityService::class)->evaluate(Student::findOrFail(1), Semester::findOrFail(1));

        $this->assertFalse($result['period']['is_open']);
        $this->assertFalse($result['can_submit']);
    }

    public function test_batch_generation_previews_creates_and_then_skips_complete_invoices(): void
    {
        DB::table('fee_structures')->insert([
            'fee_type_id' => 1, 'study_program_id' => 10, 'academic_year_id' => 20,
            'academic_level' => 3, 'amount' => 250000, 'created_at' => now(), 'updated_at' => now(),
        ]);

        $previewRequest = Request::create('/api/finance/invoices/generate-batch', 'POST', [
            'semester_id' => 1, 'due_date' => '2026-09-20', 'preview' => true,
        ]);
        $preview = app(FinanceController::class)->generateBatch($previewRequest)->getData(true);
        $this->assertSame(1, $preview['would_create']);
        $this->assertDatabaseCount('invoices', 0);

        $createRequest = Request::create('/api/finance/invoices/generate-batch', 'POST', [
            'semester_id' => 1, 'due_date' => '2026-09-20', 'preview' => false,
        ]);
        $created = app(FinanceController::class)->generateBatch($createRequest)->getData(true);
        $this->assertSame(1, $created['created']);
        $this->assertDatabaseHas('invoice_items', ['fee_type_id' => 1, 'amount' => 250000]);

        $repeated = app(FinanceController::class)->generateBatch($createRequest)->getData(true);
        $this->assertSame(0, $repeated['created']);
        $this->assertSame(1, $repeated['already_complete']);
    }
}
