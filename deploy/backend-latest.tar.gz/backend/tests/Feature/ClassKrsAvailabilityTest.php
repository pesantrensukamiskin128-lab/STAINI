<?php

namespace Tests\Feature;

use App\Http\Controllers\Api\ClassController;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Tests\TestCase;

class ClassKrsAvailabilityTest extends TestCase
{
    protected function setUp(): void
    {
        parent::setUp();

        Schema::create('study_programs', function (Blueprint $table): void {
            $table->id();
            $table->string('code');
            $table->string('name');
        });
        Schema::create('academic_years', function (Blueprint $table): void {
            $table->id();
            $table->string('name');
        });
        Schema::create('semesters', function (Blueprint $table): void {
            $table->id();
            $table->unsignedBigInteger('academic_year_id');
            $table->string('name');
        });
        Schema::create('courses', function (Blueprint $table): void {
            $table->id();
            $table->unsignedBigInteger('study_program_id');
            $table->string('code');
            $table->string('name');
            $table->unsignedInteger('credits')->default(2);
            $table->boolean('status')->default(true);
        });
        Schema::create('lecturers', function (Blueprint $table): void {
            $table->id();
            $table->string('full_name')->nullable();
        });
        Schema::create('rooms', function (Blueprint $table): void {
            $table->id();
            $table->string('name')->nullable();
        });
        Schema::create('classes', function (Blueprint $table): void {
            $table->id();
            $table->unsignedBigInteger('study_program_id');
            $table->unsignedBigInteger('semester_id');
            $table->unsignedBigInteger('course_id');
            $table->unsignedBigInteger('lecturer_id')->nullable();
            $table->unsignedBigInteger('room_id')->nullable();
            $table->string('name');
            $table->unsignedInteger('capacity')->default(40);
            $table->unsignedInteger('academic_level')->default(1);
            $table->boolean('is_active')->default(true);
            $table->timestamps();
        });
        Schema::create('class_courses', function (Blueprint $table): void {
            $table->id();
            $table->unsignedBigInteger('class_id');
            $table->unsignedBigInteger('course_id');
            $table->unsignedBigInteger('curriculum_id')->nullable();
            $table->boolean('is_primary')->default(false);
            $table->unsignedInteger('quota')->nullable();
            $table->timestamps();
        });
        Schema::create('class_members', function (Blueprint $table): void {
            $table->id();
            $table->unsignedBigInteger('class_id');
            $table->unsignedBigInteger('student_id');
        });
        Schema::create('krs', function (Blueprint $table): void {
            $table->id();
            $table->unsignedBigInteger('student_id');
        });
        Schema::create('krs_details', function (Blueprint $table): void {
            $table->id();
            $table->unsignedBigInteger('krs_id');
            $table->unsignedBigInteger('class_id')->nullable();
            $table->string('status')->default('AKTIF');
        });
        Schema::create('schedules', function (Blueprint $table): void {
            $table->id();
            $table->unsignedBigInteger('class_id');
            $table->unsignedBigInteger('room_id')->nullable();
        });

        DB::table('study_programs')->insert([
            ['id' => 1, 'code' => 'P1', 'name' => 'Prodi 1'], ['id' => 2, 'code' => 'P2', 'name' => 'Prodi 2'],
        ]);
        DB::table('academic_years')->insert(['id' => 1, 'name' => '2026/2027']);
        DB::table('semesters')->insert(['id' => 1, 'academic_year_id' => 1, 'name' => 'Ganjil']);
        DB::table('courses')->insert([
            ['id' => 1, 'study_program_id' => 1, 'code' => 'P1-01', 'name' => 'MK Prodi 1', 'status' => true],
            ['id' => 2, 'study_program_id' => 2, 'code' => 'P2-01', 'name' => 'MK Prodi 2', 'status' => true],
        ]);
        DB::table('classes')->insert([
            ['id' => 1, 'study_program_id' => 1, 'semester_id' => 1, 'course_id' => 1, 'name' => 'Kelas P1', 'is_active' => true],
            ['id' => 2, 'study_program_id' => 2, 'semester_id' => 1, 'course_id' => 2, 'name' => 'Kelas P2', 'is_active' => true],
        ]);
        DB::table('class_courses')->insert([
            ['class_id' => 1, 'course_id' => 1, 'is_primary' => true],
            ['class_id' => 2, 'course_id' => 2, 'is_primary' => true],
        ]);
    }

    public function test_student_can_list_unenrolled_classes_for_krs_in_their_program(): void
    {
        $request = Request::create('/api/classes', 'GET', [
            'semester_id' => 1, 'available_for_krs' => 1, 'per_page' => 100,
        ]);
        $request->setUserResolver(fn () => new class
        {
            public object $student;

            public function __construct()
            {
                $this->student = (object) ['id' => 100, 'study_program_id' => 1];
            }

            public function hasRole(string $role): bool
            {
                return $role === 'MAHASISWA';
            }
        });

        $response = app(ClassController::class)->index($request)->getData(true);

        $this->assertSame(1, $response['total']);
        $this->assertSame('Kelas P1', $response['data'][0]['name']);
    }
}
