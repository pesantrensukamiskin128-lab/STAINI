<?php

namespace Tests\Feature;

use App\Http\Controllers\Api\LectureController;
use App\Models\ClassModel;
use App\Models\LectureJournal;
use App\Models\User;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Illuminate\Validation\ValidationException;
use Mockery;
use Tests\TestCase;

class LectureJournalAttendanceTest extends TestCase
{
    protected function setUp(): void
    {
        parent::setUp();

        Schema::create('courses', function (Blueprint $table): void {
            $table->id();
            $table->string('code');
            $table->string('name');
        });
        Schema::create('classes', function (Blueprint $table): void {
            $table->id();
            $table->unsignedBigInteger('study_program_id');
            $table->unsignedBigInteger('semester_id');
            $table->unsignedBigInteger('course_id');
            $table->unsignedBigInteger('lecturer_id')->nullable();
        });
        Schema::create('class_courses', function (Blueprint $table): void {
            $table->id();
            $table->unsignedBigInteger('class_id');
            $table->unsignedBigInteger('course_id');
            $table->unsignedBigInteger('curriculum_id')->nullable();
            $table->boolean('is_primary')->default(false);
            $table->unsignedInteger('quota')->nullable();
            $table->timestamps();
        });
        Schema::create('class_lecturers', function (Blueprint $table): void {
            $table->id();
            $table->unsignedBigInteger('class_id');
            $table->unsignedBigInteger('lecturer_id');
            $table->unsignedInteger('teaching_order')->default(1);
            $table->unsignedInteger('planned_meetings')->nullable();
            $table->unsignedInteger('actual_meetings')->nullable();
            $table->boolean('can_input_grades')->default(true);
            $table->decimal('teaching_credits', 5, 2)->nullable();
            $table->timestamps();
        });
        Schema::create('students', function (Blueprint $table): void {
            $table->id();
            $table->string('nim');
            $table->string('name');
        });
        Schema::create('class_members', function (Blueprint $table): void {
            $table->id();
            $table->unsignedBigInteger('class_id');
            $table->unsignedBigInteger('student_id');
            $table->timestamps();
        });
        Schema::create('krs', function (Blueprint $table): void {
            $table->id();
            $table->unsignedBigInteger('student_id');
        });
        Schema::create('krs_details', function (Blueprint $table): void {
            $table->id();
            $table->unsignedBigInteger('krs_id');
            $table->unsignedBigInteger('course_id');
            $table->unsignedBigInteger('class_id')->nullable();
            $table->string('status');
        });
        Schema::create('lecture_journals', function (Blueprint $table): void {
            $table->id();
            $table->unsignedBigInteger('class_id');
            $table->unsignedInteger('meeting_number');
            $table->date('meeting_date');
            $table->string('topic');
            $table->text('description')->nullable();
            $table->text('learning_activity')->nullable();
            $table->string('status')->default('PLANNED');
            $table->unsignedBigInteger('lecturer_id')->nullable();
            $table->decimal('latitude', 10, 7)->nullable();
            $table->decimal('longitude', 10, 7)->nullable();
            $table->string('photo_path')->nullable();
            $table->timestamps();
        });
        Schema::create('attendances', function (Blueprint $table): void {
            $table->id();
            $table->unsignedBigInteger('journal_id');
            $table->unsignedBigInteger('student_id');
            $table->string('status');
            $table->string('method')->nullable();
            $table->timestamp('checked_in_at')->nullable();
            $table->text('note')->nullable();
            $table->timestamps();
            $table->unique(['journal_id', 'student_id']);
        });
        Schema::create('rpkps', function (Blueprint $table): void {
            $table->id();
            $table->unsignedBigInteger('course_id');
            $table->unsignedBigInteger('lecturer_id')->nullable();
            $table->unsignedBigInteger('semester_id')->nullable();
            $table->string('code');
            $table->string('status');
            $table->timestamps();
        });
        Schema::create('rpkps_weekly_plans', function (Blueprint $table): void {
            $table->id();
            $table->unsignedBigInteger('rpkps_id');
            $table->unsignedInteger('week_number');
            $table->text('sub_cpmk')->nullable();
            $table->text('learning_material')->nullable();
            $table->text('methods')->nullable();
        });

        DB::table('courses')->insert([
            ['id' => 1, 'code' => 'MK-A', 'name' => 'Mata Kuliah A'],
            ['id' => 2, 'code' => 'MK-B', 'name' => 'Mata Kuliah B'],
        ]);
        DB::table('classes')->insert([
            'id' => 1,
            'study_program_id' => 1,
            'semester_id' => 10,
            'course_id' => 1,
            'lecturer_id' => 5,
        ]);
        DB::table('class_courses')->insert([
            ['class_id' => 1, 'course_id' => 1, 'is_primary' => true],
            ['class_id' => 1, 'course_id' => 2, 'is_primary' => false],
        ]);
        DB::table('students')->insert([
            ['id' => 1, 'nim' => 'M001', 'name' => 'Mahasiswa Kelas'],
            ['id' => 2, 'nim' => 'M002', 'name' => 'Mahasiswa Luar'],
        ]);
        DB::table('class_members')->insert([
            'class_id' => 1,
            'student_id' => 1,
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        DB::table('lecture_journals')->insert([
            'id' => 1,
            'class_id' => 1,
            'meeting_number' => 1,
            'meeting_date' => '2026-09-16',
            'topic' => 'Topik Awal',
            'status' => 'COMPLETED',
            'lecturer_id' => 5,
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        $admin = Mockery::mock(User::class)->makePartial();
        $admin->shouldReceive('hasRole')->with('SUPER_ADMIN')->andReturn(true);
        Auth::setUser($admin);
    }

    public function test_attendance_rejects_student_outside_the_class(): void
    {
        $request = Request::create('/api/lectures/journals/1/attendances', 'POST', [
            'attendances' => [['student_id' => 2, 'status' => 'HADIR']],
        ]);

        $this->expectException(ValidationException::class);
        app(LectureController::class)->saveAttendance($request, LectureJournal::findOrFail(1));
    }

    public function test_attendance_summary_counts_only_present_students(): void
    {
        DB::table('attendances')->insert([
            ['journal_id' => 1, 'student_id' => 1, 'status' => 'IZIN'],
            ['journal_id' => 1, 'student_id' => 2, 'status' => 'HADIR'],
        ]);

        $journals = app(LectureController::class)->journalList(ClassModel::findOrFail(1))->getData(true);

        $this->assertSame(2, $journals[0]['attendances_count']);
        $this->assertSame(1, $journals[0]['present_count']);
    }

    public function test_rps_topics_are_returned_for_every_course_in_a_shared_class(): void
    {
        DB::table('rpkps')->insert([
            ['id' => 1, 'course_id' => 1, 'lecturer_id' => 5, 'semester_id' => 10, 'code' => 'RPS-A', 'status' => 'DISETUJUI', 'created_at' => now(), 'updated_at' => now()],
            ['id' => 2, 'course_id' => 2, 'lecturer_id' => 6, 'semester_id' => 10, 'code' => 'RPS-B', 'status' => 'DIKUNCI', 'created_at' => now(), 'updated_at' => now()],
        ]);
        DB::table('rpkps_weekly_plans')->insert([
            ['rpkps_id' => 1, 'week_number' => 1, 'sub_cpmk' => 'Topik RPS A', 'learning_material' => 'Materi A', 'methods' => json_encode(['Diskusi'])],
            ['rpkps_id' => 2, 'week_number' => 1, 'sub_cpmk' => 'Topik RPS B', 'learning_material' => 'Materi B', 'methods' => json_encode(['Studi kasus'])],
        ]);

        $data = app(LectureController::class)->getFromRps(ClassModel::findOrFail(1))->getData(true);

        $this->assertSame('RPS-A', $data['rpkps_code']);
        $this->assertCount(2, $data['sources']);
        $this->assertSame('Topik RPS A', $data['plans'][0]['topic']);
        $this->assertSame('Topik RPS B', $data['sources'][1]['plans'][0]['topic']);
    }
}
