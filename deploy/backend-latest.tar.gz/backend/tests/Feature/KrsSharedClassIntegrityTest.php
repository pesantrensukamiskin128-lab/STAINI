<?php

namespace Tests\Feature;

use App\Http\Controllers\Api\KrsController;
use App\Models\Krs;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Http\Request;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Tests\TestCase;

class KrsSharedClassIntegrityTest extends TestCase
{
    protected function setUp(): void
    {
        parent::setUp();

        Schema::create('students', function (Blueprint $table): void {
            $table->id();
            $table->unsignedBigInteger('study_program_id');
            $table->unsignedBigInteger('advisor_id')->nullable();
            $table->string('nim')->nullable();
            $table->string('name')->nullable();
            $table->string('status')->default('Aktif');
            $table->timestamps();
        });
        Schema::create('courses', function (Blueprint $table): void {
            $table->id();
            $table->unsignedBigInteger('study_program_id');
            $table->string('code');
            $table->string('name');
            $table->unsignedInteger('credits');
            $table->boolean('status')->default(true);
            $table->timestamps();
        });
        Schema::create('semesters', function (Blueprint $table): void {
            $table->id();
            $table->string('name')->nullable();
        });
        Schema::create('classes', function (Blueprint $table): void {
            $table->id();
            $table->unsignedBigInteger('study_program_id');
            $table->unsignedBigInteger('semester_id');
            $table->unsignedBigInteger('advisor_id')->nullable();
            $table->unsignedBigInteger('course_id');
            $table->unsignedBigInteger('lecturer_id')->nullable();
            $table->unsignedBigInteger('room_id')->nullable();
            $table->string('name');
            $table->unsignedInteger('capacity')->default(40);
            $table->unsignedInteger('academic_level')->default(1);
            $table->boolean('is_active')->default(true);
            $table->timestamps();
        });
        Schema::create('class_courses', function (Blueprint $table): void {
            $table->id();
            $table->unsignedBigInteger('class_id');
            $table->unsignedBigInteger('course_id');
            $table->unsignedBigInteger('curriculum_id')->nullable();
            $table->boolean('is_primary')->default(false);
            $table->unsignedInteger('quota')->nullable();
            $table->timestamps();
        });
        Schema::create('krs', function (Blueprint $table): void {
            $table->id();
            $table->unsignedBigInteger('student_id');
            $table->unsignedBigInteger('semester_id');
            $table->unsignedInteger('total_credits')->default(0);
            $table->string('status')->default('DRAFT');
            $table->timestamps();
        });
        Schema::create('krs_details', function (Blueprint $table): void {
            $table->id();
            $table->unsignedBigInteger('krs_id');
            $table->unsignedBigInteger('course_id');
            $table->unsignedBigInteger('class_id')->nullable();
            $table->string('status')->default('AKTIF');
            $table->timestamps();
        });
        Schema::create('class_members', function (Blueprint $table): void {
            $table->id();
            $table->unsignedBigInteger('class_id');
            $table->unsignedBigInteger('student_id');
            $table->timestamps();
        });

        DB::table('students')->insert([
            ['id' => 1, 'study_program_id' => 1, 'nim' => 'MHS-001', 'name' => 'Mahasiswa Satu'],
            ['id' => 2, 'study_program_id' => 2, 'nim' => 'MHS-002', 'name' => 'Mahasiswa Dua'],
        ]);
        DB::table('courses')->insert([
            ['id' => 1, 'study_program_id' => 1, 'code' => 'A-1', 'name' => 'Mata Kuliah A', 'credits' => 2],
            ['id' => 2, 'study_program_id' => 1, 'code' => 'A-2', 'name' => 'Mata Kuliah B', 'credits' => 2],
            ['id' => 3, 'study_program_id' => 2, 'code' => 'B-1', 'name' => 'Mata Kuliah C', 'credits' => 2],
        ]);
        DB::table('semesters')->insert([['id' => 1], ['id' => 2]]);
        DB::table('classes')->insert([
            ['id' => 1, 'study_program_id' => 1, 'semester_id' => 1, 'course_id' => 1, 'name' => 'Gabungan A', 'capacity' => 40, 'is_active' => true],
            ['id' => 2, 'study_program_id' => 1, 'semester_id' => 2, 'course_id' => 1, 'name' => 'Semester Lain', 'capacity' => 40, 'is_active' => true],
        ]);
        DB::table('class_courses')->insert([
            ['class_id' => 1, 'course_id' => 1, 'is_primary' => true],
            ['class_id' => 1, 'course_id' => 3, 'is_primary' => false],
            ['class_id' => 2, 'course_id' => 1, 'is_primary' => true],
        ]);
        DB::table('krs')->insert([
            ['id' => 1, 'student_id' => 1, 'semester_id' => 1, 'status' => 'DRAFT'],
            ['id' => 2, 'student_id' => 2, 'semester_id' => 1, 'status' => 'DRAFT'],
        ]);
    }

    public function test_rejects_a_class_that_does_not_offer_the_selected_course(): void
    {
        $response = $this->addCourse(1, 2, 1);

        $this->assertSame(422, $response->getStatusCode());
        $this->assertSame('Mata kuliah tidak ditawarkan pada kelas yang dipilih.', $response->getData(true)['message']);
    }

    public function test_rejects_a_class_from_another_semester(): void
    {
        $response = $this->addCourse(1, 1, 2);

        $this->assertSame(422, $response->getStatusCode());
        $this->assertSame('Kelas tidak berada pada semester KRS yang dipilih.', $response->getData(true)['message']);
    }

    public function test_rejects_a_course_from_another_study_program(): void
    {
        $response = $this->addCourse(1, 3, 1);

        $this->assertSame(422, $response->getStatusCode());
        $this->assertSame('Mata kuliah tidak berasal dari program studi mahasiswa.', $response->getData(true)['message']);
    }

    public function test_accepts_a_matching_course_and_class(): void
    {
        $response = $this->addCourse(1, 1, 1);

        $this->assertSame(200, $response->getStatusCode());
        $this->assertDatabaseHas('krs_details', ['krs_id' => 1, 'course_id' => 1, 'class_id' => 1]);
        $this->assertDatabaseHas('class_members', ['class_id' => 1, 'student_id' => 1]);
    }

    public function test_admin_can_import_krs_for_multiple_students_with_class_validation(): void
    {
        $csv = implode("\n", [
            'nim,nama_mahasiswa,kode_prodi,id_semester,nama_semester,kode_mata_kuliah,id_kelas,nama_kelas,status_krs,total_sks',
            'MHS-001,Mahasiswa Satu,,1,,A-1,1,Gabungan A,DRAFT,',
        ]);
        $file = UploadedFile::fake()->createWithContent('krs.csv', $csv);
        $request = Request::create('/api/krs/import', 'POST', [], [], ['file' => $file]);
        $request->setUserResolver(fn () => new class
        {
            public function hasAnyRole(array $roles): bool
            {
                return true;
            }
        });

        $response = app(KrsController::class)->import($request);

        $this->assertSame(200, $response->getStatusCode());
        $this->assertSame(1, $response->getData(true)['processed']);
        $this->assertDatabaseHas('krs_details', ['krs_id' => 1, 'course_id' => 1, 'class_id' => 1]);
    }

    private function addCourse(int $krsId, int $courseId, int $classId)
    {
        $request = Request::create('/api/krs/'.$krsId.'/courses', 'POST', [
            'course_id' => $courseId,
            'class_id' => $classId,
        ]);
        $request->setUserResolver(fn () => new class
        {
            public function hasRole(string $role): bool
            {
                return false;
            }

            public function hasAnyRole(array $roles): bool
            {
                return true;
            }
        });

        return app(KrsController::class)->addCourse($request, Krs::findOrFail($krsId));
    }
}
